﻿<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
   

    <!-- Title Page-->
    <title>Tables</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">

    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
     
    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

    <style>
    body{
     margin:0px;
	}
   @media only screen and (max-width: 993px) {
  .w3-container {
    visibility:hidden;
    display:none;
  }

   @media only screen and (max-width: 739px) {
  .w3-container {
    visibility:hidden;
    margin:0px;
    padding:-10px;
    display:none;
  }
   }

    </style>
    
</head>


<?php
include 'includes/db.inc.php';
?>	
 <div class="w3-container" style="width:100%;padding-left:0%;padding-right:0%;padding-top:0%;text-align:center;margin:0px;position:fixed;top:0px;z-index:3;">

  <div class="w3-bar w3-black" style="padding:2%;margin:0px;text-align:center;">
   
   <a href="index.php" class="w3-bar-item w3-button">Home</a>
   <?php
   if(isset($_SESSION['studentLOGIN']))
    {
     echo '<a href="GradeSheet.php" class="w3-bar-item w3-button">Grade Book <i class="fa fa-file-text"></i></a>';
	}
    ?>

      

    <div class="w3-dropdown-hover">
      <button class="w3-button">ABOUT</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">    
              
               
                   <a class="w3-bar-item w3-button" href="developer.php">About The Developer</a>
                   <a class="w3-bar-item w3-button" href="contact.php">Contact</a>
      </div>
    </div>

       <div class="w3-dropdown-hover">
      <button class="w3-button">COURSE</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a class="w3-bar-item w3-button" href="https://www.zybooks.com/" target="_blank">ZyBooks</a>
       <a class="w3-bar-item w3-button" href="https://tophat.com/" target="_blank">TopHat</a>
       <a class="w3-bar-item w3-button" href="https://drive.google.com/drive/folders/1co7vzY9_75cCiuNTHXCGf3pKbpf_TTwC" target="_blank">Course Google Drive</a>
       <a class="w3-bar-item w3-button" href="https://www.w3schools.com/" target="_blank">W3Schools</a>

      </div>
    </div>

    
    <?php

    if(isset($_SESSION['userid']))
    {
    
	?>
        <div class="w3-dropdown-hover">
      <button class="w3-button"><b>MY ACCOUNT </b><i class="fas fa-caret-down"></i></button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4" style="min-width:260px;">
     <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img style="width:50px;"  src="images/login.png" alt="John Doe" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                <?php
                                                echo'
                                                    <h5 class="name">
                                                        <a href="#">'.$_SESSION["username"].'</a>
                                                    </h5> ';
                                                    ?>
                                                    <?php
                                                   echo' <span class="email">'.$_SESSION["email"].'</span> ';
                                                   ?>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account
                                                    </a>
                                                </div>
                                               
                                            </div>
                                            
                                             <div class="account-dropdown__footer">
                                                <a href="includes/logout.inc.php">
                                                    <i class="zmdi zmdi-power"></i>Logout
                                                </a>
                                            </div>
                                        </div>  
                                        
                                      
        

    </div>

     <?php
                                        }
                                        ?>
    
 <?php
 if(isset($_SESSION['professorLogin'])||isset($_SESSION['studentLOGIN']))
 {
  ?>
 <form action="includes/logout.inc.php">
 <button class="w3-bar-item w3-button" style="color:white;" type="submit" name="logout">LOGOUT <i class="fas fa-sign-out-alt" aria-hidden="true"></i></button>
 </form>
 
 <?php
 
 }
 else {
  echo ' <a class="w3-bar-item w3-button" href="Signup_sharedview.php"> SIGNUP </a> 
  <div class="w3-dropdown-hover">
      <button class="w3-button"><i class="fas fa-sign-in-alt"> </i> Sign in</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="loginStudent.php" class="w3-bar-item w3-button">As a Student</a>
        <a href="loginTeacher.php" class="w3-bar-item w3-button">As a Professor</a>
     

      </div>
    </div>
    ';
   // echo ' <a class="w3-bar-item w3-button" href="Signup_sharedview.php"><i class="fas fa-sign-in-alt"> </i> SIGN IN </a> ';
	# code...
}

 ?>
 <a href="https://www.youtube.com/watch?v=2uloZRSMkM8&feature=youtu.be" class="w3-bar-item w3-button">HELP</a>


  </div>
</div>



<body style="background-color:#f4f4f4;" class="animsition">
<?php 
    // include 'header.php';
?>
    
        <!-- HEADER MOBILE-->

       
        <header class="header-mobile d-block d-lg-none" style="margin-top:0%;">
            <div class="header-mobile__bar" style="background-color:black;">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/logo.png" alt="tophatlogo" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">

                    <li class="active">
                            <a href="index.php">
                                <i class="fas fa-tachometer-alt"></i>HOME PAGE
                            </a>
                        </li>
                     


                         <?php 
                    if(isset($_SESSION['professorLogin']))
                    {
   				
                    ?>
                            <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-table"></i>ADD NEW ITEMS
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                <li>
                                    <a href="ProfessorAddQuesLec.php">Choose Item to Add</a>
                                </li>
                                <li>
                                    <a href="addMCQ.php"> + Add MCQ Questions</a>
                                </li>
                                <li>
                                     <a href="ProfessorAddQuesLec.php"> + Add One Word Question Answers</a>
                                </li>
                                 <li>
                                    <a href="addMCQ.php"> + Add MCQ Questions</a>
                                </li>
                                
                                 <li>
                                    <a href="ChoosingAssignmentType.php">+ Add Assignments</a>
                                </li>
                            </ul>
                        </li>

                        <?php
                        
                        
						}

                        ?>


                         <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="far fa-check-square"></i>Assignments(Word Answers)
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">

                             <?php
                            $QuestionQueryResult=mysqli_query($conn,"select Distinct QuesGroupName FROM questiongroupmcq");


                 while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	                          {	

                            ?>
                                <li>
                                    <a href="ChoosingAssignment.php?groupname=<?php echo $Questionrow["QuesGroupName"];?>"><?php echo $Questionrow["QuesGroupName"]; ?> </a>

                                </li>
                                
                               <?php 
                                }
                                ?>
                               
                            </ul>
                        </li>

                          <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="far fa-check-square"></i>Assignments(MCQ)
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">

                             <?php
                            $QuestionQueryResult=mysqli_query($conn,"select Distinct QuesGroupName FROM questiongroupword");


                 while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	                          {	

                            ?>
                                <li>
                                    <a href="ChoosingAssignment.php?groupname=<?php echo $Questionrow["QuesGroupName"];?>"><?php echo $Questionrow["QuesGroupName"]; ?> </a>

                                </li>
                                
                               <?php 
                                }
                                ?>
                               
                            </ul>
                        </li>

                        
                            <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-calendar-alt"></i>Multiple Choice Questions
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">

                             <?php
                            $QuestionQueryResult=mysqli_query($conn,"select Distinct LectureTopic FROM mcq_questions");


                 while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	                          {	

                            ?>
                                <li>
                                    <a href="AnswerMCQ2.php?lecturetopic=<?php echo $Questionrow["LectureTopic"];?>"><?php echo $Questionrow["LectureTopic"]; ?> </a>

                                </li>
                                
                               <?php 
                                }
                                ?>
                               
                            </ul>
                        </li>

                        
                            <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>One Word Question Answers
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">

                             <?php
                            $QuestionQueryResult=mysqli_query($conn,"select Distinct LectureTopic FROM one_word_questions");


                 while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	                          {	

                            ?>
                                <li>
                                    <a href="Answer_OneWordQuesBa.php?lecturetopic=<?php echo $Questionrow["LectureTopic"];?>"><?php echo $Questionrow["LectureTopic"]; ?> </a>

                                </li>
                                
                               <?php 
                                }
                                ?>
                               
                            </ul>
                        </li>

                      
                       
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-desktop"></i>Admin Information
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">

                                
                                <li>
                                    <a  href="developer.php"><i class="fas fa-table"></i>About the developer</a>
                                </li>
                                 <li>
                                    <a  href="contact.php"><i class="fas fa-table"></i>Contact Information</a>
                                </li>

                     
                      
                        
                        
			

                    </ul>
                </div>
            </nav>
            <?php
            if(isset($_SESSION['userid']))
            {
            
			
            ?>
             <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu" style="float:right;">
                                        <div class="image">
                                            <img src="images/login.png" alt="<?php echo $_SESSION['username']; ?>" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">MY ACCOUNT</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="images/login.png" alt="<?php echo $_SESSION['username']; ?>" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo $_SESSION['username']; ?></a>
                                                    </h5>
                                                    <span class="email"><?php echo $_SESSION['email']; ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account
                                                    </a>
                                                </div>
                                               
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="includes/logout.inc.php">
                                                    <i class="zmdi zmdi-power"></i>Logout
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                }
                                else{


                                ?>

                                 <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu" style="float:right;">
                                       
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">SIGN IN</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                           
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="loginTeacher.php">
                                                        <i class="zmdi zmdi-account"></i>As a Professor
                                                    </a>
                                                </div>
                                               
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="loginStudent.php">
                                                        <i class="zmdi zmdi-account"></i>As a Student
                                                    </a>
                                                </div>
                                               
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="Signup_sharedview.php">
                                                    <i class="zmdi zmdi-power"></i>Sign Up
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php
								}
                                ?>
        </header>
        
        </div

      
        <!-- END MENU SIDEBAR-->
        <!-- PAGE CONTAINER-->
        
            <!-- Jquery JS-->
            <script src="vendor/jquery-3.2.1.min.js"></script>
            <!-- Bootstrap JS-->
            <script src="vendor/bootstrap-4.1/popper.min.js"></script>
            <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
            <!-- Vendor JS       -->

            <script src="vendor/animsition/animsition.min.js"></script>

            <!-- Main JS-->
            <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
