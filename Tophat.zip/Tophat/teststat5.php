<!DOCTYPE html>
<html lang="en">

<head>

<?php include 'includes/db.inc.php';
session_start();
unset($_SESSION["answersoneword"]);
?>
	<!-- Required meta tags-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	

	<!-- Title Page-->
	<title>Test Results</title>

	<!-- Fontfaces CSS-->
	<link href="css/font-face.css" rel="stylesheet" media="all">
	<link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
	<link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
	<link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

	<!-- Bootstrap CSS-->
	<link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

	<!-- Vendor CSS-->
	<link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
	<link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
	<link href="vendor/wow/animate.css" rel="stylesheet" media="all">
	<link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
	<link href="vendor/slick/slick.css" rel="stylesheet" media="all">
	<link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
	<link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

	<!-- Main CSS-->
	<link href="css/theme.css" rel="stylesheet" media="all">
	<?php //include 'tabled.php'; ?>
	<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>


    $(document).ready(function(){
        $("#scrollmodal").modal('show');
    });
</script>
</head>

<body class="animsition" style="animation-duration: 0ms; opacity: 1;">

<div class="modal fade" id="scrollmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="scrollmodalLabel">TEST RESULTS</h5>
							<a  href="GradeSheet.php" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</a>
						</div>
						<div class="modal-body">
						<table id="tabled" style="margin-top:1%;margin-bottom:1%; padding-bottom:2%; width:100%;" class="table table-striped table-bordered">
 <thead class="thead-dark">
            <tr>
                <th width="12%">QUESTION </th>
                <th width="8%">Actual Answer</th>
               
                <th width="8%">Your Answer</th>
                  
                <th width="10%">Status</th>
            </tr>
		</thead>	
		    <?php
                                              $userid=$_SESSION["userid"];
											  $lec="";
											  if(isset($_GET["lecc"]))
											  { $lec=$_GET["lecc"];
											  }
											   $idd=0;
											  if(isset($_GET["id"]))
											  { $idd=(int)$_GET["id"];
											  }
                                            
                                              echo '<h4 style="color:green;">'.'ASSIGNMENT: </h4><p>'.$lec.'</p>';
											   echo '<h4 style="color:black;margin-top:2%;">'.'WORD ANSWER RESULTS </h4>';
$QuestionQueryResult=mysqli_query($conn,"select * FROM awaresultrev where lecturetopic LIKE '$lec' and sid =$idd");
while($QuestionRow=mysqli_fetch_array($QuestionQueryResult))
{
   
   
                    echo '<tr>
                          <td> <b>'.$QuestionRow["question"].'?</b></td> ';
							
                         echo  ' <td>'.$QuestionRow["actualanswer"]. '</td> ';
                        
                            echo '<td>'.$QuestionRow["studentsanswer"].'</td>';  
                          
                          
 if($QuestionRow["status"]=="Correct")
 {
       echo '<td style="background-color:#50C878;"><b></b>'. $QuestionRow["status"] . '</td>';
 }
 else {
	echo ' <td style="background-color:#CA3444; color:white;"><b></b>'. $QuestionRow["status"] . '</td> ';
}

  
                    


                     echo '</tr>';
                                             
       
           }
             echo '   </table> '; 
			  echo '<h4 style="color:black;margin-top:2%;">'.'MCQ RESULTS </h4>';
                 ?>
				 				<table id="tabled" style="margin-top:1%;margin-bottom:1%; padding-bottom:2%; width:100%;" class="table table-striped table-bordered">
 <thead class="thead-dark">
            <tr>
                <th width="12%">QUESTION </th>
                <th width="8%">Actual Answer</th>
               
                <th width="8%">Your Answer</th>
                  
                <th width="10%">Status</th>
            </tr>
		</thead>
		<?php 
            


$QuestionQueryResult=mysqli_query($conn,"select * FROM amcqresultrev where lecturetopic LIKE '$lec' and sid =$idd");
while($QuestionRow=mysqli_fetch_array($QuestionQueryResult))
{
   
   
                    echo '<tr>
                          <td> <b>'.$QuestionRow["question"].'?</b></td> ';
							
                         echo  ' <td>'.$QuestionRow["actualanswer"]. '</td> ';
                        
                            echo '<td>'.$QuestionRow["studentsanswer"].'</td>';  
                          
                          
 if($QuestionRow["status"]=="Correct")
 {
       echo '<td style="background-color:#50C878;"><b></b>'. $QuestionRow["status"] . '</td>';
 }
 else {
	echo ' <td style="background-color:#CA3444; color:white;"><b></b>'. $QuestionRow["status"] . '</td> ';
}

  
                    


                     echo '</tr>';
                                             
       
           }
             echo '   </table> '; 
                 
            ?>

						</div>
						<div class="modal-footer">
							<a  href="GradeSheet.php" class="btn btn-secondary" data-dismiss="modal">Cancel</a
						
						</div>
					</div>
				</div>
			</div>
		

		</div>
    </div>
</body>

	<!-- Jquery JS-->
	<script src="vendor/jquery-3.2.1.min.js"></script>
	<!-- Bootstrap JS-->
	<script src="vendor/bootstrap-4.1/popper.min.js"></script>
	<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
	<!-- Vendor JS       -->
	<script src="vendor/slick/slick.min.js">
	</script>
	<script src="vendor/wow/wow.min.js"></script>
	<script src="vendor/animsition/animsition.min.js"></script>
	<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
	</script>
	<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendor/counter-up/jquery.counterup.min.js">
	</script>
	<script src="vendor/circle-progress/circle-progress.min.js"></script>
	<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
	<script src="vendor/chartjs/Chart.bundle.min.js"></script>
	<script src="vendor/select2/select2.min.js">
	</script>

	<!-- Main JS-->
	<script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
