
<?php
    session_start();
	require 'includes/db.inc.php';

    $TYPE="";
    if(isset($_GET["type"]))
    {
     $TYPE=$_GET["type"];
	}
  $_SESSION['mcq_score']=0; 
  unset($_SESSION['answersoneword']);
   unset($_SESSION['answersmcq']);

?>



<!doctype html>

<html>

<head>
<title>
Choosing Lecture/Exam Type

</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<link rel="stylesheet" href="css/bootstrap.min.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  
    <style>
    body{
     margin:0px;
	}
   @media only screen and (max-width: 693px) {
  .section{
    margin-left:0%;
    margin-top:25%;
  }
  }

   @media only screen and (min-width: 700px) {
  .section{
    margin-left:0%;
    margin-top:15%;
    
  }
  }

   @media only screen and (min-width: 800px) {
 
  .section
  {
     margin-left:25%;
  }

     }

     @media only screen and (min-width: 992px) {
 
  .section
  { margin-top:5%;
     margin-left:25%;
  }

     }

    </style>
</head>
 <?php 
    include 'tabled.php';
?>
<body>



  <div class="section">
 
                   


                     <h4 style="text-align:center;margin-top:2%;margin-right:7%;margin-bottom:2%;text-transform:Uppercase;"> Choose a topic to your liking! </h4>
                    

                    <?php
                    if($TYPE=="mcq")
                    {
                    
					
                    ?>


                        <div class="row" style="text-align:center;">
                                                    <?php
                            $QuestionQueryResult=mysqli_query($conn,"select Distinct LectureTopic FROM mcq_questions");


while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	{	
      
?>
                          <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">ASSIGNMENT TYPES</strong>
                                    </div>
                                    <div class="card-body " style="background:#CDE2BB;">
                                       
                                         <div class="text">
                                               
                      
                                                <h2 style="color:#808070;">Lecture Topic: <?php echo $Questionrow["LectureTopic"]; ?></h2>
                                                <h3 style="color:black;margin-top:6%;margin-bottom:6%;">(MCQ) </h3>
                                              <p style="color:#808080;">Test how much you know about this topic by giving an MCQ exam!</p>
                                                    <a href="AnswerMCQ2.php?lecturetopic=<?php echo $Questionrow["LectureTopic"];  ?>&n=1" 
                                                  class="btn btn-default" name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:black;color:white; margin-top:5%;">CLICK HERE </a>
                                                 
                                            </div>
                                       
                                       
                                    </div>
                                </div>
                            </div>    
                            <?php
                                 }
                            ?>
</div>

<?php
}


if($TYPE=="wa")
{


?>

       
       <div class="row" style="text-align:center;">                   
                           <?php
                            $QuestionQueryResult=mysqli_query($conn,"select Distinct LectureTopic FROM one_word_questions");


while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	{	

?> <div class="col-md-5">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">WORD ANSWERS</strong>
                                    </div>
                                    <div class="card-body " style="background:#3EB489;">
                                        
                                       <div class="text">
                                               
                      
                                                <h3 style="color:white;">Topic : <?php echo $Questionrow["LectureTopic"]; ?></h3>
                                                <p style="color:white;margin-top:3%;margin-bottom:3%;">(Answer in One Word) </p>
                                              <p style="color:black;">Test how much you know about this topic by answering these questions in just one word!</p>
                                                    <a href="Answer_OneWordQuesBa.php?lecturetopic=<?php echo $Questionrow["LectureTopic"];  ?>&n=1" 
                                                 class="btn btn-default" style="background-color:white; margin-top:2%;">CLICK HERE </a>
                                                 
                                            </div>
                                    </div>
                                </div>
                            </div>
                          
                            <?php
                                 }
                            ?>
                   </div>

                   <?php
                   }

                   ?>
                        </div>


<div>
			
			          
</body>
<?php //include 'footer.php'; ?>
</html>
