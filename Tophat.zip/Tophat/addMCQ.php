﻿
<?php
	require 'includes/db.inc.php';


    session_start();
?>

<?php


$LectureTopic="";
if(isset($_POST['submitmcq']))
{


	
  
	$selOption=$_POST["answernumber"];

	$Choices= array();
	$Choices[1]=$_POST["firstop"];
	$Choices[2]=$_POST["secondop"];
	$Choices[3]=$_POST["thirdop"];
	$Choices[4]=$_POST["fourthop"];
	$Choices[5]=$_POST["fifthop"];
	$Choices[6]=$_POST["sixthop"];
	$LectureTopic=$_POST["lecturetopic"];

	$is_correct=0;
$queryResult1=mysqli_query($conn,"INSERT into mcq_questions(QuestionNumber,Textt,LectureTopic,submissiondate) VALUES
($_POST[questionnumber],'$_POST[question]','$LectureTopic','$_POST[date]')");

$date=$_POST["date"];
$result=mysqli_query($conn,"SELECT * from mcq_questions ");
$QID= mysqli_num_rows($result);

	foreach($Choices as $choice =>$value)
	{
		if($value !='')
		{
		if($choice==$selOption)
		{$is_correct=1;
		
		}
		else {
		 $is_correct=0;
	# code...
             }

             

$queryResult2=mysqli_query($conn,"INSERT into mcq_choices(QuestionNumber,Is_Correct,Textt,LectureTopic) VALUES
('$QID','$is_correct','$value','$LectureTopic')");
		
		}
		

	}
	
 	
    $queryResult3=mysqli_query($conn,"SELECT * from mcq_questions WHERE LectureTopic LIKE '$LectureTopic'");
     
  
     $RowCount=mysqli_num_rows($queryResult3);
        $total=$RowCount;
        $next=$total+1;
        

       

//header("Location:../addMCQ.php");

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CS 355 Add MCQ Questions</title>
 
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
     h1{
        padding-top: 20%; 
        color: #f9f9f9;
        text-align: center;
     }
     p{
        color: #f9f9f9;
     }
     h4
     {
      color:green;
      text-transform:capitalize;
     
      text-align:center;
	 }
  
       input[type="number"]
     {
      max-width:550px;
      min-width:440px;
     
	 }
   
    .form-horizontal

    { display:inline-block;}

      @media only screen and (min-width: 992px) {
  .section{
    margin-left:32%;
    margin-top:5%;
    
  }

    input[type="text"]
     {
      max-width:550px;
      min-width:440px;
     
	 }
       input[type="number"]
     {
      max-width:550px;
      min-width:440px;
     
	 }

     .alert
     {width:600px;
      margin-left:8%;
	 }
  }

   @media only screen and (max-width: 892px) {
  .section{
    margin-left:0%;
    margin-top:25%;
    
  }

    input[type="text"]
     {
      max-width:450px;
      min-width:340px;
     
	 }
     input[type="number"]
     {
      max-width:450px;
      min-width:340px;
     
	 }

   

     .alert-class
     {  margin-left:2%;
      margin-top:15%;
	 }
  }

   @media only screen and (max-width: 600px) {
  .section{
    margin-left:0%;
    margin-top:25%;
    
  }

    input[type="text"]
     {
      max-width:450px;
      min-width:340px;
     
	 }
     input[type="number"]
     {
      max-width:450px;
      min-width:340px;
     
	 }

     

      .alert-class
     {
      
      margin-top:15%;
    
	 }
  }

 
    
  </style>


</head>
<body>
   <!-- NAVBAR BEGINS HERE-->


     <?php 
    include 'tabled.php';
?>
<div class="section">
<?php
if(isset($_SESSION['professorLogin']))
{

?>
    
  <div style="margin-top:5%;" class="container">
  <h4>Add Question</h4>
      <?php

    


    ?>
  <form class="form-horizontal" action="addMCQ.php?" method="post">
    
     <div class="form-group">
      <label class="control-label col-sm-2" for=Question>Question Number:</label>
      <div class="col-sm-10">
        <input type="number" class="form-control" placeholder="" required value="<?php echo $next; ?>"  name="questionnumber">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for=Question>Question:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control"required  placeholder="Enter the Question" name="question">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for=date>Due Date: </label>
      <div class="col-sm-10">
        <input type="date" name="date" value="<?php echo $date; ?>" class="input-text" class="form-control" required>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for=LectureTopic>Assignment/<br>Exam Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" required value="<?php echo $LectureTopic; ?>" placeholder="Enter the LectureTopic" name="lecturetopic">
      </div>
    </div>
   


  <h4>Add the options</h4>
  

    <div class="form-group">
      <label class="control-label col-sm-2" for=First Option>1st Option:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" required  placeholder="Enter first option" name="firstop">
      </div>
    </div> 
    <div class="form-group">
      <label class="control-label col-sm-2" for=Second Option>2nd Option:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" required placeholder="Enter second option" name="secondop">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for=Third Option>3rd Option:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" required placeholder="Enter third option" name="thirdop">
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for=Fourth Option>4th Option:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" required placeholder="Enter fourth option" name="fourthop">
      </div>
    </div>
       <div class="form-group">
      <label class="control-label col-sm-2" for=Fourth Option>5th Option:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control"  placeholder="Enter fifth option" name="fifthop">
      </div>
    </div>
       <div class="form-group">
      <label class="control-label col-sm-2" for=Fourth Option>Sixth Option:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control"  placeholder="Enter sixth option" name="sixthop">
      </div>
    </div>
     <h4>Choose the option</h4
    <div class="form-group">
      <label class="control-label col-sm-2" for=Question>Correct Option No:</label>
      <div class="col-sm-10">
        <input type="number" class="form-control" required placeholder="Enter correct option no. Example: 5" min="1" max="6" name="answernumber">
      </div>
    </div>
 
     
    
     <button type="submit" id="submitmcq" name="submitmcq"
     style="font-size:20px; padding:1% 3%; margin:5% 50% 5% 45%; display:block;"  class="btn btn-success">Submit</button>
      <hr>
  </form>

 
</div>
<?php
}

else {
	 echo '
     <div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%;" class="alert alert-danger">
  <strong>You need to be have a Professor Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%;" class="alert alert-success">
  Sign up using a Professor or Student account <a href="Signup_sharedview.php"><b> HERE</b></a></div> 
  </div>
  ';
}

?>
</div>
</body>


</html>