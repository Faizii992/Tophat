﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
  
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">


    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
  <title>Developer Info</title>

  <style>
     h1{
       
        color: black;
        
     }
     p{
        color: black;
     }

   @media only screen and (max-width:500px) {
 
  .section
  { 
     margin-top:18%;
  }
 
  }

  @media only screen and (min-width:767px) {
 
  .section
  { 
     margin-left:18%;
  }
  .col-md-4 
  {
  margin-left:20%;
  }

  .devtext
  {
      margin-top:10%;
  }
  }
   
   @media only screen and (min-width: 1024px) {
 
  .section
  { 
     margin-left:16%;
  }
  .col-md-4 
  {
  margin-left:35%;
  }

  .devtext
  {
      margin-left:15%;
  }
  }

  </style>
  <?php 
 session_start();
include 'tabled.php';
?>
</head>

<body>
<div class="section" style=" text-align:center;">
<div class="devtext col-md-9">
   <h1>Developer</h1>
   <br>
   <p>
     Welcome to my Website.  </p>
<p>My name is <strong>Mohammed Rahat</strong> and I am a Computer Science Undergraduate Student at Queens College.
</div>

                              <div class="card col-md-4 col-sm-5" style="margin-top:1.5%; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">   
                                    <div class="card-header" style="background:#CDE2BB;">
                                        <strong class="card-title mb-3" >DEVELOPER INFO</strong>
                                    </div>
                                    <div class="card-body">
                                        <div class="mx-auto d-block">
                                            <img class="rounded-circle mx-auto d-block" style="width:60px;" src="images/login.png" alt="Card image cap">
                                            <h5 class="text-sm-center mt-2 mb-1">Mohammed Rahat</h5>
                                            <div class="location text-sm-center">
                                                <i class="fa fa-map-marker"></i> NY, United States
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="card-text text-sm-center">
                                            <a href="#">
                                                <i class="fab fa-facebook"></i>
                                            </a>
                                            <a href="#">
                                                <i class="fab fa-twitter"></i>
                                            </a>
                                            <a href="#">
                                                <i class="fab fa-instagram"></i>
                                            </a>
                                            <a href="#">
                                                <i class="fab fa-pinterest"></i>
                                            </a>
                                             <a href="#">
                                                <i class="fab fa-linkedin"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
 </div> 
</body>
</html>