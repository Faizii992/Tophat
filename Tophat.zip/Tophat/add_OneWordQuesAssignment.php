﻿
<?php
	require 'includes/db.inc.php';

    $TYPE="";
    if(isset($_GET["type"]))
    {
     $TYPE=$_GET["type"];
	}
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CS 355 Add Word Answers</title>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
     h1{
        padding-top: 20%; 
        color: #f9f9f9;
        text-align: center;
     }
     p{
        color: #f9f9f9;
     }
     h4
     {
      color:green;
      text-transform:capitalize;
     
      
	 }
    input[type="text"]
     {
      max-width:500px;
      min-width:400px;
     
	 }
     body
     { text-align:center;}

    .form-horizontal

    { display:inline-block;}

    .form-control{
     margin:1% 0% ;
	}

    @media only screen and (min-width: 992px) {
  .section{
    margin-left:32%;
    margin-top:10%;
    
  }
  }
    @media only screen and (max-width: 692px) {
  .section{
    margin-left:3%;
    margin-top:15%;
    
  }
  input[type="text"]
     {
      max-width:450px;
      min-width:350px;
     
	 }

  }
   
    
  </style>
</head>
<?php include 'tabled.php'; ?>

<body>
<?php

if(isset($_SESSION['professorLogin']))
{

?>
   <!-- NAVBAR BEGINS HERE-->
   <div class="section">
  <div>

    <hr width="500" height="20">
  <div class="container">
  <?php
  if($TYPE=="both")
  {
    echo '<form class="form-horizontal" action="includes/input_OneWordQuesAssignment.php?type='.$TYPE.'" method="post">';
  }
  else {
    echo '<form class="form-horizontal" action="includes/input_OneWordQuesAssignment.php" method="post">';
	# code...
}

?>
    

    <div class="form-group">
      <label class="control-label col-sm-2" for=Question>Question:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control"  placeholder="Enter the Question" required name="question">
      </div>
    </div>
    
        <input type="hidden" class="form-control" required placeholder="Enter the Topic/Assignment Name" name="lecture">
     


  

    <div class="form-group">
      <label class="control-label col-sm-2" for=Answer>Answer:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control"  placeholder="Enter Answer" required name="answer">
      </div>
    </div> 
    


     <button type="submit" id="submitmcq" name="submitmcqa"
     style="font-size:20px; padding:1% 3%; margin:5% 50% 5% 45%; display:block;"  class="btn btn-success">Submit</button>
  
  </form>
 
   <a class="btn btn-default" style="background-color:black;color:white;margin-bottom:8%;margin-left:10%; " href="savingtoQuestionGroupwa.php?type=<?php echo $TYPE; ?>">Add assignment questions to Question groups </a>
	

     <hr>
</div>
</div>
<?php
}

else {
	 echo '<div style="font-size:20px; text-align:center; padding:1%; width:500px;margin-left:35%;margin-top:5%"; class="alert alert-danger">
  <strong>You need to be have a Professor Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%; width:500px;margin-left:35%;margin-top:3%"; class="alert alert-success">
  <strong>Sign up using a Professor or Student account</strong><a href="Signup_sharedview.php">HERE</a></div> 
  
  ';
}

?>

</div>
</body>
</html>