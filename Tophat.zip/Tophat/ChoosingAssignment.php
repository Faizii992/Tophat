

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">


    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
     <title>
CS355 Choose Assignment
</title>
    <link rel="stylesheet" type="text/css" href="css/sourcesanspro-font.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
 <style>
    body{
     margin:0px;
	}
   @media only screen and (max-width: 693px) {
  .section{
    margin-left:0%;
    margin-top:25%;
  }
  }

   @media only screen and (min-width: 700px) {
  .section{
    margin-left:0%;
    margin-top:15%;
    
  }
  }

   @media only screen and (min-width: 800px) {
 
  .section
  {
     margin-left:25%;
  }

     }

       @media only screen and (min-width: 1000px) {
 
  .section
  { margin-top:5%;
     margin-left:35%;
  }

  .col-lg-5
  {
      margin-right:4%;
  }
  .alert
  {
      margin-left:2%;
      width:600px;
  }

     }

     @media only screen and (min-width: 1025px) {
 
  .section
  { margin-top:5%;
     margin-left:25%;
  }

  .col-lg-5
  {
      margin-right:4%;
  }
    .alert
  {
      margin-left:5%;
      width:800px;
  }

     }

    </style>
</head>

    <?php
    session_start();
    include 'tabled.php';
    unset($_SESSION['answersoneword']);
    $grpname="";
     if(isset($_GET['groupname']))
    {$grpname=$_GET['groupname'];
    
	}
    ?>
   
      <div class="section">
    <?php
    if(!isset($_SESSION['userid']))
    {
     echo '<div style="font-size:20px; text-align:center; padding:1%;margin-top:5%"; class="alert alert-danger">
  <strong>You need to login to avail this feature </strong></div> 
  
  ';
	}
    else {
	# code...


    ?>
   
   <div class="row" style="text-align:center">
  <div class="col-md-5">
                                <div class="card">
                                    <div class="card-header bg-success">
                                        <strong class="card-title text-light">Multiple Choice Questions</strong>
                                    </div>
                                    <div class="card-body text-white bg-warning">
                                        
                                           <p style="color:#f4f4f4;"><b> Complete this assignment given by your professor</b></p>
                                           <p class="card-text text-light"> This is an MCQ based assignment and it was assigned by your professor to the
                                            Assignment marked as <b>"<?php echo $grpname; ?></b>".
                                        </p>
                                        <a style="margin-top:8%;" href="AnswerMCQ2Assignment.php?groupname=<?php echo $grpname; ?>" class="btn btn-success"> CLICK HERE TO START</a>
                                    </div>

                                </div>
                                
                                
                            </div>
                            <div class="col-md-5">
                                <div class="card">
                                    <div class="card-header bg-success">
                                        <strong class="card-title text-light">Word Answers</strong>
                                    </div>
                                    <div class="card-body text-white bg-warning">
                                       
                                           <p style="color:#f4f4f4;"><b> Complete this assignment given by your professor</b></p>
                                           <p class="card-text text-light">  This is an Word answer based assignment and it was assigned by your professor to the
                                            Assignment marked as <b>"<?php echo $grpname; ?> </b>".
                                        </p>
                                         <a style="margin-top:8%;" href="Answer_OneWordQuesAssignment.php?groupname=<?php echo $grpname; ?>" class="btn btn-success"> CLICK HERE TO START</a>
                                    </div>
                                </div>
                            </div>
</div>



                        <?php
                        }
                        ?>
</div>
</div>



</body>
</html>