<!DOCTYPE html>

<?php include 'includes/db.inc.php';
session_start();
unset($_SESSION["answersoneword"]);
?>
<html lang="en">

<head>


	<!-- Required meta tags-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	

	<!-- Title Page-->
	<title>ASSIGNMENTS</title>

	<!-- Fontfaces CSS-->
	<link href="css/font-face.css" rel="stylesheet" media="all">
	<link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
	<link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
	<link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

	<!-- Bootstrap CSS-->
	<link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

	<!-- Vendor CSS-->
	<link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">

	<link href="vendor/wow/animate.css" rel="stylesheet" media="all">
	

	<!-- Main CSS-->
	<link href="css/theme.css" rel="stylesheet" media="all">
	<?php //include 'tabled.php'; ?>
	<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style>

   @media only screen and (max-width: 692px) {
 #tabled
{
	margin-left:0%;
	margin-top:20%;
	margin-bottom:10%;
	text-align:center;
	width:100%;
}


  }

  @media only screen and (min-width: 992px) {
 #tabled
{
	margin-left:25%;
	margin-top:5%;
	margin-bottom:10%;
	text-align:center;
	width:70%;
}


  }

</style>
<?php
include 'tabled.php';
?>
</head>
       <?php
       $R1=mysqli_query($conn,"select * FROM questiongroupmcq ");
$rc1=mysqli_num_rows($R1);
    $R2=mysqli_query($conn,"select * FROM mcq_questions");
$rc2=mysqli_num_rows($R2);
$R3=mysqli_query($conn,"select * FROM one_word_questions ");
$rc3=mysqli_num_rows($R3);
if(($rc1==0)&&($rc2==0)&&($rc3==0))
{
    echo '<div style="font-size:20px; text-align:center; padding:1%;margin-top:10%; width:500px;margin-left:40%;" class="alert alert-danger">
  <strong>There is nothing to show!</strong><br>No Quizzes were Created!<br></div> ';
}
else {
	# code...


       ?>
<body class="animsition">
<?php
if(isset($_SESSION["studentLOGIN"]))
{

?>

<div id="tabled" class="table-responsive table-responsive-data2 ">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                
                                                <th><b>Assignment Name</b></th>
												 <th><b>Question Type</b></th>
                                                <th><b>Due Date</b></th>
                                                <th><b>Status</b></th>
                                                <th><b>Action</b></th>
                                                
                                              
                                                
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                        
                                                  
                                                

                                               <tr class="tr-shadow">
                                            <?php
                                                  $userid=$_SESSION["userid"];
											  $lec="";
											  if(isset($_GET["lecc"]))
											  { $lec=$_GET["lecc"];
											  }
											   $idd=0;
											  if(isset($_GET["id"]))
											  { $idd=(int)$_GET["id"];
											  }

                                         
$QuestionQueryResult=mysqli_query($conn,"select DISTINCT QuesGroupName,submissiondate from questiongroupmcq  ");
while($QuestionRow=mysqli_fetch_array($QuestionQueryResult))
{
   
   
                    echo '<tr>
                          <td> <b>'.$QuestionRow["QuesGroupName"].'</b></td> ';
						  $grpname="";
                                    $grpname=   $QuestionRow["QuesGroupName"];
                                        
                                    ?>
									<td><span class="block-email">Word Answer + MCQ </span></td>
									 
									<td><?php echo $QuestionRow["submissiondate"];?></td>
									<?php
						$QuestionQResult=mysqli_query($conn,"select * from amcqrevstat where sid=$userid and lecturetopic LIKE '$grpname'");
						$rc=mysqli_num_rows($QuestionQResult);
						if($rc>0)
						{
							echo '<td>
							 <span class="block-email">COMPLETED</span>
							</td>';
							echo '<td><button class="btn btn-danger" data-toggle="modal" data-target="#smallmodal" ><i class="fas fa-ban"></i> TAKE QUIZ </button></td>
							
						
							';
						}
						else {
						echo '<td>DUE</td>';
							echo '<td><a href="AnswerMCQ2Assignment.php?groupname='.$grpname.'" class="btn btn-success" disabled><i class="fas fa-check-circle"></i> TAKE QUIZ </a></td>';
	# code...
}


						?>
                                             
                                            </tr>

                                               <tr class="spacer"></tr>
                                     
									 <?php
                                            }
											

											$QuestionQuery=mysqli_query($conn,"select DISTINCT LectureTopic,submissiondate from mcq_questions  ");
while($QRow=mysqli_fetch_array($QuestionQuery))
{
   
   
                    echo '<tr>
                          <td> <b>'.$QRow["LectureTopic"].'</b></td> ';
						  $grpname="";
                                    $grpname=   $QRow["LectureTopic"];
                                        
                                    ?>
									<td><span class="block-email">MCQ Based Questions </span></td>
									<td><?php echo $QRow["submissiondate"];?></td>
									<?php
						$QuestionQResult=mysqli_query($conn,"select * from mcqrevstat where sid=$userid and lecturetopic LIKE '$grpname'");
						$rc=mysqli_num_rows($QuestionQResult);
						if($rc>0)
						{
							echo '<td>
							 <span class="block-email">COMPLETED</span>
							</td>';
							echo '<td><button class="btn btn-danger" data-toggle="modal" data-target="#smallmodal" ><i class="fas fa-ban"></i> TAKE QUIZ </button></td>
							
						
							';
						}
						else {
						echo '<td>DUE</td>';
							echo '<td><a href="AnswerMCQ2.php?lecturetopic='.$grpname.'" class="btn btn-success" disabled><i class="fas fa-check-circle"></i> TAKE QUIZ </a></td>';
	# code...
}


						?>
                                             
                                            </tr>

                                               <tr class="spacer"></tr>
                                     
									 <?php
                                            }
											?>

											           
									 <?php
                                            
											

											$QuestionQuery=mysqli_query($conn,"select DISTINCT LectureTopic,submissiondate from one_word_questions ");
while($QRow=mysqli_fetch_array($QuestionQuery))
{
   
   
                    echo '<tr>
                          <td> <b>'.$QRow["LectureTopic"].'</b></td> ';
						  $grpname="";
                                    $grpname=   $QRow["LectureTopic"];
                                        
                                    ?>
									<td><span class="block-email">Word Answer Based Questions </span></td>
									<td><?php echo $QRow["submissiondate"];?></td>
									<?php
						$QuestionQResult=mysqli_query($conn,"select * from warevstat where sid=$userid and lecturetopic LIKE '$grpname'");
						$rc=mysqli_num_rows($QuestionQResult);
						if($rc>0)
						{
							echo '<td>
							 <span class="block-email">COMPLETED</span>
							</td>';
							echo '<td><button class="btn btn-danger" data-toggle="modal" data-target="#smallmodal" ><i class="fas fa-ban"></i> TAKE QUIZ </button></td>
							
						
							';
						}
						else {
						echo '<td>DUE</td>';
							echo '<td><a href="Answer_OneWordQuesBa.php?lecturetopic='.$grpname.'" class="btn btn-success" disabled><i class="fas fa-check-circle"></i> TAKE QUIZ </a></td>';
	# code...
}


						?>
                                             
                                            </tr>

                                               <tr class="spacer"></tr>
                                     
									 <?php
                                            }
											?>


                                        </tbody>
                                    </table>

                                </div>
                                <!-- END DATA TABLE -->
                       
<div style="text-align:center;margin-top:10%;" class="modal fade" id="smallmodal" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true">
				<div class="modal-dialog modal-sm" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="smallmodalLabel">ALERT MESSAGE!</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<p>
								YOU ALREADY COMPLETED THIS ASSIGNMENT <br>
								<button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-top:3%;">Close</button>
							</p>
						</div>
						
					</div>
				</div>
			</div>
			<?php
			}

			
else if(isset($_SESSION["professorLogin"]))
{

?>

<div id="tabled" class="table-responsive table-responsive-data2 ">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                
                                                <th><b>Name of Assignment</b></th>
												 <th><b>Type of Question</b></th>
                                                <th><b>Date <br> of <br>Submission</b></th>
                                              <th><b>Student's Results</b></th>
												<th><b>No of Students who finished</b></th>
                                                
                                              
                                                
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                        
                                                  
                                                

                                               <tr class="tr-shadow">
                                            <?php
                                                  $userid=$_SESSION["userid"];
											  $lec="";
											  if(isset($_GET["lecc"]))
											  { $lec=$_GET["lecc"];
											  }
											   $idd=0;
											  if(isset($_GET["id"]))
											  { $idd=(int)$_GET["id"];
											  }

                                         
$QuestionQueryResult=mysqli_query($conn,"select DISTINCT QuesGroupName,submissiondate from questiongroupmcq  ");
while($QuestionRow=mysqli_fetch_array($QuestionQueryResult))
{
   
   
                    echo '<tr>
                          <td> <b>'.$QuestionRow["QuesGroupName"].'</b></td> ';
						  $grpname="";
                                    $grpname=   $QuestionRow["QuesGroupName"];
                                        
                                    ?>
									<td><span class="block-email">Word Answer + MCQ </span></td>
									<td><?php echo $QuestionRow["submissiondate"];?></td>
									 <td>
                                                
                                                <a href="teststat4.php?lec=<?php echo $grpname; ?>&type=mcqwa" style="color:white;" class="btn btn-secondary mb-1"  data-lec="<?php echo $lecc; ?>" data-toggle="modal" data-target="#scrollmodal">
											<i class="mr-2 fa fa-align-justify"></i>Show Content
										</a></td>
													<?php
									$QQResult=mysqli_query($conn,"select DISTINCT sid from amcqrevstat where lecturetopic LIKE '$grpname'");
						$rc=mysqli_num_rows($QQResult);
						echo '<td>'.$rc.'</td>';
						?>
						
                                             
                                            </tr>

                                               <tr class="spacer"></tr>
                                     
									 <?php
                                            }
											

											$QuestionQuery=mysqli_query($conn,"select DISTINCT LectureTopic,submissiondate from mcq_questions  ");
while($QRow=mysqli_fetch_array($QuestionQuery))
{
   
   
                    echo '<tr>
                          <td> <b>'.$QRow["LectureTopic"].'</b></td> ';
						  $grpname="";
                                    $grpname=   $QRow["LectureTopic"];
                                        
                                    ?>
									<td><span class="block-email">MCQ </span></td>
									<td><?php echo $QRow["submissiondate"];?></td>
									    <td>
                                                
                                                <a href="teststat4.php?lec=<?php echo $grpname; ?>&type=mcq" style="color:white;" class="btn btn-secondary mb-1">
											<i class="mr-2 fa fa-align-justify"></i>Show Content
										</a></td>
									<?php
									$QQResult=mysqli_query($conn,"select DISTINCT sid from mcqrevstat where lecturetopic LIKE '$grpname'");
						$rc=mysqli_num_rows($QQResult);
						echo '<td>'.$rc.'</td>';
						?>
									
						
                                             
                                            </tr>

                                               <tr class="spacer"></tr>
                                     
									 <?php
                                            }
											?>

											           
									 <?php
                                            
											

											$QuestionQuery=mysqli_query($conn,"select DISTINCT LectureTopic,submissiondate from one_word_questions ");
while($QRow=mysqli_fetch_array($QuestionQuery))
{
   
   
                    echo '<tr>
                          <td> <b>'.$QRow["LectureTopic"].'</b></td> ';
						  $grpname="";
                                    $grpname=   $QRow["LectureTopic"];
                                        
                                    ?>
									<td><span class="block-email">Word Answer</span></td>
									<td><?php echo $QRow["submissiondate"];?></td>
									 <td>
                                                
                                                <a href="teststat4.php?lec=<?php echo $grpname; ?>$type=wa" style="color:white;" class="btn btn-secondary mb-1">
											<i class="mr-2 fa fa-align-justify"></i>Show Content
										</a></td>
											<?php
									$QQResult=mysqli_query($conn,"select DISTINCT sid from warevstat where lecturetopic LIKE '$grpname'");
						$rc=mysqli_num_rows($QQResult);
						echo '<td>'.$rc.'</td>';
						?>
					
                                             
                                            </tr>

                                               <tr class="spacer"></tr>
                                     
									 <?php
                                            }
											?>


                                        </tbody>
                                    </table>

                                </div>
                                <!-- END DATA TABLE -->
                       
<div style="text-align:center;margin-top:10%;" class="modal fade" id="smallmodal" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true">
				<div class="modal-dialog modal-sm" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="smallmodalLabel">ALERT MESSAGE!</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<p>
								YOU ALREADY COMPLETED THIS ASSIGNMENT <br>
								<button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-top:3%;">Close</button>
							</p>
						</div>
						
					</div>
				</div>
			</div>
			<?php
			}
			}
			?>


</body>

	

</html>
<!-- end document-->
