﻿
<?php
	require 'includes/db.inc.php';


    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>CS 355 Add Word Answers</title>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/header.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
     h1{
        padding-top: 20%; 
        color: #f9f9f9;
        text-align: center;
     }
     p{
        color: #f9f9f9;
     }
     h4
     {
      color:green;
      text-transform:capitalize;
     
      
	 }
    input[type="text"]
     {
      max-width:500px;
      min-width:400px;
     
	 }
     body
     { text-align:center;}

    .form-horizontal

    { display:inline-block;}

    .form-control{
     margin:1% 0% ;
	}

    @media only screen and (min-width: 992px) {
  .section{
    margin-left:32%;
margin-top:10%;  
    
  }
  }
    @media only screen and (max-width: 692px) {
  .section{
    margin-left:5%;
    margin-top:15%;
   
    
  }
  input[type="text"]
     {
      max-width:480px;
      min-width:380px;
     
	 }

  }
   
    
  </style>
</head>
<?php include 'tabled.php'; ?>

<body>
<?php

if(isset($_SESSION['professorLogin']))
{

?>

   <div class="section">
  <div>

    <hr width="500" height="20">
  <div class="container">

  <form class="form-horizontal" action="includes/input_OneWordQues.php" method="post">
    

    <div class="form-group">
      <label class="control-label col-sm-2" for=Question>Question:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" required placeholder="Enter the Question" name="question">
      </div>
    </div>

    <?php
    if(isset($_GET["lec"]))
    {
     $lec=$_GET["lec"];
	}
    else {
	# code..
     $lec="";
}


  if(isset($_GET["date"]))
    {
     $date=$_GET["date"];
	}
    else {
	# code..
     $date="";
}

    ?>
    <div class="form-group">
      <label class="control-label col-sm-2" for=LEcture>Topic Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" value="<?php echo $lec; ?>" required placeholder="Enter the Topic/Assignment Name" name="lecture">
      </div>
    </div>

     <div class="form-group">
      <label class="control-label col-sm-2" for=date>Due Date: </label>
      <div class="col-sm-10">
        <input type="date" name="date" value="<?php echo $date; ?>" class="input-text" class="form-control" required>
      </div>
    </div>


  

    <div class="form-group">
      <label class="control-label col-sm-2" for=Answer>Answer:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" required placeholder="Enter Answer" name="answer">
      </div>
    </div> 

     <button type="submit" id="submitmcq" name="submitmcq"
     style="font-size:20px; padding:1% 3%; margin:5% 50% 5% 45%; display:block;"  class="btn btn-success">Submit</button>
   
  </form>

 
</div>
</div>
<?php
}

else {
	 echo '<div style="font-size:20px; text-align:center; padding:1%; width:500px;margin-left:35%;margin-top:5%"; class="alert alert-danger">
  <strong>You need to be have a Professor Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%; width:500px;margin-left:35%;margin-top:3%"; class="alert alert-success">
  <strong>Sign up using a Professor or Student account</strong><a href="Signup_sharedview.php">HERE</a></div> 
  
  ';
}

?>

</div>
</body>
</html>