﻿
<?php
	require 'includes/db.inc.php';
    $TYPE="";
    if(isset($_GET["type"]))
    {
     $TYPE=$_GET["type"];
	}

    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Saving to Question Group</title>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/header.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />

  <style>
     h1{
         
        color: #f9f9f9;
        text-align: center;
     }
     p{
        color: black;
        opacity:0.5;
     }
     h4
     {
      color:green;
      text-transform:capitalize;
     
      
	 }
    input[type="text"]
     {
      max-width:450px;
      min-width:400px;
     
	 }
     body
     { text-align:center;}

    .form-horizontal

    { display:inline-block;}

    .form-control{
     margin:1% 0% ;
	}

    @media only screen and (min-width: 992px) {
  .section{
    margin-left:32%;
    margin-top:5%;
    
  }
  }
    @media only screen and (max-width: 692px) {
  .section{
    margin-left:2%;
    margin-top:25%;
    
  }
  input[type="text"]
     {
      max-width:400px;
      min-width:300px;
     
	 }

  }
   
    
  </style>
</head>
<?php include 'tabled.php'; ?>

<body>
<?php

if(isset($_SESSION['professorLogin']))
{

?>

   <div class="section">
  <div>

  <div class="container">
  <?php
  if($TYPE!=="both")
  {
      echo ' <form class="form-horizontal" action="includes/savingtoQuestionGroup.incwa.php" method="post">';
  }
  else {
	# code...

 echo ' <form class="form-horizontal" action="includes/savingtoQuestionGroup.incboth.php" method="post">';
 }
 ?>
    

    <h3 style="margin-top:3%;">Enter a new Group name:</h3>
        <input type="text" class="form-control"  placeholder="Enter a new Question Group Name" name="questiongroup">
      
      <div class="divtext">
     
      <p>Select a submission date</p>
      </div>
 <input type="date" name="date" class="input-text" required>


    <h3 style="margin-top:5%;"> Add Word answer questions to the group: </h3>
    <p>Hold down the Ctrl (windows) or Command (Mac) button to select multiple options.</p>
  <select style="width:450px;" name="ary[]" multiple="multiple" required>
      <?php
    {
     
$QuestionQueryResult=mysqli_query($conn,"select * FROM assignment_one_word_questions");
while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	{

    ?>
    <option value="<?php echo $Questionrow["Qid"]; ?> "><?php echo $Questionrow["Question"]; ?> </option>


    <?php
    }
    }

    ?>
  </select>
 <?php  
 if($TYPE=="both")
 {

 ?>
      <h3 style="margin-top:5%;"> Add MCQ questions to the group: </h3>
    <p>Hold down the Ctrl (windows) or Command (Mac) button to select multiple options.</p>
  <select style="width:450px;" name="ary2[]" multiple="multiple" required>
      <?php
    {
     
$QuestionQueryResult=mysqli_query($conn,"select  * FROM assignment_mcq_questions");
while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	{

    ?>
    <option value="<?php echo $Questionrow["QuestionID"]; ?> "><?php echo $Questionrow["Textt"]; ?> </option>


    <?php
    }
    }

    ?>
  </select>
 }

 <?php
 }

 ?>
                              
  <button type="submit" id="submitmcq" name="submitmcq"
     style="font-size:20px; padding:1% 3%; margin:5% 5% 5% 0%; display:block;"  class="btn btn-success">Submit Group Name</button>
</form>
</div>
</div>
<?php
}

else {
	 echo '<div style="font-size:20px; text-align:center; padding:1%; width:500px;margin-left:35%;margin-top:5%"; class="alert alert-danger">
  <strong>You need to be have a Professor Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%; width:500px;margin-left:35%;margin-top:3%"; class="alert alert-success">
  <strong>Sign up using a Professor or Student account</strong><a href="Signup_sharedview.php">HERE</a></div> 
  
  ';
}

?>

</div>
</body>
</html>