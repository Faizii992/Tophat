
<?php
    session_start();
	require 'includes/db.inc.php';
    $ques_no=1;
    $lecture_topic="";
       if(isset($_GET['lecturetopic']))
    {
    $lecture_topic=(string)$_GET['lecturetopic'];
	}
      if(isset($_GET['n']))
    {
    $ques_no=(int)$_GET['n'];
	}
	
  

 

?>

<!doctype html>

<html>

<head>
<title>
Multiple Choice Test
</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



<link rel="stylesheet" href="css/bootstrap.min.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <?php 
    include 'tabled.php';
?>

<style>
 @media only screen and (max-width: 600px) {
  .content
  {
  margin-top:25%;
  }

 
   .alert-class
  {
  margin-top:30%;
  }
  }

  @media only screen and (min-width: 766px) {
  .content
  {
  margin-top:30%;
  }

 
   .alert-class
  {
  margin-top:36%;
  }
  }

   @media only screen and (min-width: 905px) {
  .content
  {
  margin-top:5%;
  margin-left:13%;
  }

  .alert{
  margin-left:32%;
  width:680px;
  
  }

   .alert-class
  {
  margin-top:8%;
  }
  }

   @media only screen and (min-width: 760px) {
  .content
  {
  margin-top:5%;
  margin-left:13%;
  }

  .alert-class
  {
  margin-top:8%;
  }
 
  }

</style>
</head>

<body>

<?php
if(isset($_SESSION['studentLOGIN']))
{
$SID=$_SESSION['userid'];
$QuestionQResult=mysqli_query($conn,"select * FROM mcqrevstat where sid=$SID and LectureTopic Like '$lecture_topic'");

$check=mysqli_num_rows($QuestionQResult);
if($check>0)
{echo '<div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%"; class="alert alert-danger">
  <strong>You have already taken this quiz!</strong></div> 
  <div style="font-size:20px; text-align:center; padding:1%"; class="alert alert-success">
  <strong><a id="takelec" href="GradeSheet.php" > YOU CAN FIND ALL YOUR TEST RESULTS IN YOUR GRADEBOOK</a></strong></div>
  
  </div>
  ';
  

}
else {
	# code...


?>
    <div class="content">
<h3 style="text-align:center; margin-top:2%;text-transform:Uppercase"> <b> Choose the Correct option </b></h3> 
<?php
$queryResult3=mysqli_query($conn,"SELECT * from mcq_questions where LectureTopic LIKE '$lecture_topic' ");
    if($queryResult3)
    {
     $RowCount=mysqli_num_rows($queryResult3);
        $total_ques=$RowCount;
        

	}
 ?>
<p style="text-align:center"> Question <?php echo $ques_no; ?> of <?php echo $total_ques; ?>  </p>
<?php

$QuestionQueryResult=mysqli_query($conn,"select * FROM mcq_questions where QuestionNumber = $ques_no and LectureTopic Like '$lecture_topic'");
$QuestionRow=mysqli_fetch_array($QuestionQueryResult);
$Row_Count=mysqli_num_rows($QuestionQueryResult);
if($Row_Count==0)
{ echo'<script>window.alert("There is no Multiple Choice Question related to this topic")';
echo'<script>window.location("ChoosingQuestionType.php")';

}
$QID= $QuestionRow["QuestionID"];
$AnsQueryResult=mysqli_query($conn,"select * FROM mcq_choices where QuestionNumber LIKE '$QID'");

echo ' <h1 style="color:green; text-align:center;">' .$QuestionRow["Textt"] . '?</h1>';
while($AnswerRows=mysqli_fetch_array($AnsQueryResult))
	{	

?>


  <div class="container col-md-12">
   <center>

  <form class="form-horizontal" action="process.php?id=<?php echo $QID;?>&lecturetopic=<?php echo $lecture_topic; ?>" method="post">



      <input type="hidden" name="questionnumber" value="<?php echo $ques_no; ?>">  
       <input type="hidden" name="questiontext" value="<?php echo $QuestionRow["Textt"]; ?>"> 
        <input type="hidden" name="questionID" value="<?php echo $QID; ?>">  
    <label class="radio">
      <input value="<?php echo $AnswerRows["AnsID"]; ?>" type="radio" name="studentschoice"> <?php echo $AnswerRows["Textt"] ?>
    </label>
  
       
  </center>

<?php 

}
?>
  <button type="submit" id="submitAnswers" name="submitAnswers"
     style="font-size:15px; padding:0.4% 2%; margin:auto; display:block;"  class="btn btn-success">Submit Answer</button>
        <button type="submit" id="submitAnswers" name="comp"
   
   
  </form>
  <?php
}
}
else {
	 echo '
     <div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%"; class="alert alert-danger">
  <strong>You need to be have a Student Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%;" class="alert alert-success">
  <strong>Sign up using a Professor or Student account</strong><a href="Signup_sharedview.php">HERE</a></div> 
  </div>
  ';
}

?>   
 </div>
			          
</body>
<?php //include 'footer.php'; ?>
</html>
