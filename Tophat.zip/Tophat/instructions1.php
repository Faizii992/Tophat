
<?php
    session_start();
	require 'includes/db.inc.php';
    $ques_no=1;
    $lecture_topic="";
       if(isset($_GET['lecturetopic']))
    {
    $lecture_topic=(string)$_GET['lecturetopic'];
	}
      if(isset($_GET['n']))
    {
    $ques_no=(int)$_GET['n'];
	}
	
  

 

?>



<style>
.form-horizontal
{
    
}

input
{
    font-size:40px;
}


</style>





<!doctype html>

<html>

<head>
<title>
Instructions 
</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="css/bootstrap.min.css">
 
<link rel="stylesheet" href="css/header.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <?php 
    include 'tabled.php';
?>
<style>
p{
    margin-bottom:2%;
}
img
{
    margin-top:7%;
    margin-bottom:2%;
}
@media only screen and (max-width: 590px) {
  .content
  {
  margin-top:30%;
  margin-left:0%;
 
  }

  img
  {
      margin-bottom:10%;
  }
  }

 

   @media only screen and (min-width: 750px) {
  .content
  {
  margin-top:8%;
  margin-left:0%;
 
  }

   img
  {
      margin-bottom:10%;
  }
  }

     @media only screen and (min-width: 950px) {
  .content
  {
  margin-top:4%;
  margin-left:23%;
 
  }
  }
  img
  {
      margin-bottom:2%;
  }

</style>
</head>

<body>
<div class="content">
<div class="container" style="text-align:center;" >
<div class="row">
<div class="col-md-6">
<img src="images/step6.jpg" style="transform:scale(0.8)">
<p>1. a)Fill up all the information properly. <br> 1. b)Input your mcq choices and Question Number properly starting with a 1. </p>
</div>
<div class="col-md-6">
<img src="images/step7.JPG" style="transform:scale(0.8)">
<p>2. a)Input your correct choice number/option number.<br> In case of our example the correct answer the choice number 1.<br>b) Then hit <b>SUBMIT </b> to add the next mcq question if you want to add more. <br>c) OR click the black button below to start adding word answers</p>
</div>
<div class="col-md-6">
<img src="images/step8.JPG">
<p>3)You can leave choices 5,6 empty but it's mandatory to fillup the first four textboxes for the mcq choices</p>
</div>
<div class="col-md-6">
<img src="images/step9.JPG">
<p>4)When you hit <b>SUBMIT </b> you'll be asked to input the information for the next Question you want to add. Follow <b>Step 1 </b> to fill it up in the right way. </p>
</div>
<div class="col-md-6">
<img src="images/step10.JPG">
<p>5)When you click the black button you'll be asked to provide inputs for the word answers. </p>
</div>
<div class="col-md-6">
<img src="images/step11.JPG">
<p>6)Fillup the information as required and then hit <b> SUBMIT </b> if you want to add more word answer based questions. <br> Or click the black button below to add questions to a group. This group will later be discoverable to the student to complete later on.</p>
</div>
<div class="col-md-6">
<img src="images/step12.JPG">
<p>7)Once you click the black button you'll be asked to input the Question Group/Assignment Name. And the submission date and the questions you wish you add to that group. Choose accordingly.</p>
</div>
<div class="col-md-6">
<img src="images/step13.JPG">
<p>8)Hold Down the CTRL(Windows) OR Command(MAC) to select or unselect questions and select a submission date from the datepicker</p>
<p>FINALLY CLICK THE SUBMIT button to complete the whole procedure </p>
</div>

<hr>
</div>
</div>

	</div>		          
</body>
<?php //include 'footer.php'; ?>
</html>
