<?php

	require 'db.inc.php';
	 session_start();
	// $count=0;


if(isset($_POST['submitAnswers']))
{
   

		
$result = mysqli_query($conn,"SELECT * FROM anwertablemcq INNER join questiontablemcq WHERE answertablemcq.AnsID 
= questiontable.Qid");
/*($_POST[optradio],'$_POST[question]','$optiontext','$ss')");

$result1=mysqli_query($conn,"INSERT into answertablemcq(ActualAnsID,LectureTopic,FirstOption,SecondOption,ThirdOption,FourthOption,ActualAnswer) VALUES
($_POST[optradio],'$_POST[lecture]','$_POST[firstop]','$_POST[secondop]','$_POST[thirdop]','$_POST[fourthop]','$optiontext')");
*/
$option=$_POST["optradio"];
//header("Location:../AnswerMCQ.php");
//echo  $option;
//$_SESSION["pnt"][++$count]=$option;



print_r($_SESSION);
}


?>
