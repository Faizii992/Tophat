<?php

if(isset($_POST['signup']))
{
	
	require 'db.inc.php';

$username=$_POST['username'];
$email=$_POST['email'];
$password=$_POST['password'];
$password_repeat=$_POST['confirmpassword'];


if(empty($username) || empty($email) || empty($password) || empty(password_repeat))
{
	
	header("Location: ../signupTeacher.php?error=emptyfields&uid=".$username."&mail=".$email);
	exit();
	
}
else if(!filter_var($email,FILTER_VALIDATE_EMAIL)&&!preg_match("/^[a-zA-Z0-9]*$/",$username))
{
	header("Location: ../signupTeacher.php?error=invalidemailuid");
	exit();
	
}

else if(!filter_var($email,FILTER_VALIDATE_EMAIL))
{
	header("Location: ../signupTeacher.php?error=invalidemail&uid=".$username);
	exit();
	
}

else if(!preg_match("/^[a-zA-Z0-9]*$/",$username))
{
	header("Location: ../signupTeacher.php?error=invalidemail&mail=".$email);
	exit();
	
}
else if($password!==$password_repeat)
{
	header("Location: ../signupTeacher.php?error=passwordcheck&uid=".$username."&mail=".$email);
	exit();
	
}
else
{
	
	$sql= "SELECT Username FROM professorregistration WHERE Username=?";
	$stmt=mysqli_stmt_init($conn);
	if(!mysqli_stmt_prepare($stmt,$sql))
	{
		header("Location: ../signupTeacher.php?error=sqlerror");
		
		exit();
	}
	
	
	else
	{
		
		mysqli_stmt_bind_param($stmt,"s",$username);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_store_result($stmt);
		$resultcheck=mysqli_stmt_num_rows($stmt);
		
		if($resultcheck>0)
		{
			header("Location: ../signupTeacher.php?error=usertaken&mail=".$email);
		
		exit();
			
			
		}
		else
		{
			
				
	$sql= "INSERT INTO professorregistration(username,Email,Password) VALUES(?,?,?)";
	$stmt=mysqli_stmt_init($conn);
	
	
		if(!mysqli_stmt_prepare($stmt,$sql))
	{
		header("Location: ../signupTeacher.php?error=sqlerror");
		
		exit();
	}
	else
	{
		$hashedpwd=password_hash($password,PASSWORD_DEFAULT);
		
		mysqli_stmt_bind_param($stmt,"sss",$username,$email,$hashedpwd);
		mysqli_stmt_execute($stmt);
		
				   										
			 echo' <div style="font-size:25px; text-align:center; padding:1%;" class="alert alert-success">
  <strong>Thankyou for signing up!! </strong> Please Login Using The Form Below!!</div> ';
		header("Location: ../loginTeacher.php?signup=success");
	
          
		exit();
		
		
		
		
	}
		
		}
		
	}
	
	mysqli_stmt_close($stmt);
	mysqli_close($conn);
}
}
	else
	{
		header("Location: ../signupTeacher.php?");
		exit();
		
		
		
	}
	
?>	
	











