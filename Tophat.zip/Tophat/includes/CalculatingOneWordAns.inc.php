<?php

	require 'db.inc.php';
	 session_start();
	// $count=0;


if(isset($_POST['submitAnswers']))
{
   $ans=$_POST['answer'];
   echo $ans;
		
$result = mysqli_query($conn,"SELECT * FROM anwertablemcq INNER join questiontablemcq WHERE answertablemcq.AnsID 
= questiontable.Qid");

}


?>
