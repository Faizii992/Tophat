<?php

	require 'db.inc.php';



if(isset($_POST['submitmcq']))
{
  
    $FirstOption=$_POST["firstop"];
    $SecondOption=$_POST["secondop"];
	$ThirdOption=$_POST["thirdop"];
	$FourthOption=$_POST["fourthop"];
	$selectedOption=$_POST["optradio"];
	$selOption=$_POST["answernumber"];

	$Choices= array();
	$Choices[0]=$_POST["firstop"];
	$Choices[1]=$_POST["secondop"];
	$Choices[2]=$_POST["thirdop"];
	$Choices[3]=$_POST["fourthop"];
	$Choices[4]=$_POST["fifthop"];
	$Choices[5]=$_POST["sixthop"];
	
	$query1=mysqli_query($conn,"INSERT into mcq_questions(QuestionNumber,Textt) VALUES
($_POST[questionnumber],'$_POST[question]')");

	foreach($Choices as $choice =>$value)
	{
		if($value !='')
		{
		if($choice==$selOption)
		{$is_correct=1;
		
		}
		else {
		 $is_correct=0;
	# code...
             }


		
		}
		
$query2=mysqli_query($conn,"INSERT into mcq_choices(QuestionNumber,Is_Correct,Textt) VALUES
($_POST[questionnumber],'$is_correct','$_POST[question]')");
	}
	$query3=mysqli_query($conn,"SELECT count(QuestionID) from mcq_questions");
	$next=
	$optiontext="";
	if($selectedOption==1)
	{
		$optiontext=$FirstOption;
	}
	else if($selectedOption==2)
	{
		$optiontext=$SecondOption;
	}
	else if($selectedOption==3)
	{
		$optiontext=$ThirdOption;
	}
	else if($selectedOption==4)
	{
		$optiontext=$FourthOption;
	}

	
	$ss=$_POST["Lecture"];
	
	echo $ss;

		
	//$id=$POST['id'];
//$result=mysqli_query($conn,"UPDATE 'users' SET emailusers='$_POST['email']',address='$_POST['address']',gender='$_POST['gender']',number='$_POST['number']',profilepic='$_FILES['profilepic']',firstname='$_POST['firstname']',lastname='$_POST['lastname']',bio='$_POST['bio']' WHERE idusers='$uid'");

//$result=mysqli_query($conn,"INSERT into questiontablemcq(ActualAnsID,Question) VALUES
//('','$_POST[servicename]',$_POST[serviceprice])");




header("Location:../addMCQ.php");

}


?>


<!DOCTYPE html>


<head>

<title> Inp</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="css/profpagecard.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
</head>



<body>

	
	</body>
	
	
	</html>