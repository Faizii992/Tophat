<?php

	require 'db.inc.php';

    if(isset($_POST['submitmcq']))
    {
    
	
$grpname="";
   
      $grpname=$_POST["questiongroup"];


$date=$_POST["date"];
$values2 = $_POST['ary2'];
$no=1;
foreach ($values2 as $a2)
{
$query=mysqli_query($conn,"INSERT into questiongroupmcq(MCQQuesID,QuesGroupName,QuestionNumber,submissiondate) VALUES
('$a2','$grpname',$no,'$date') ");
$no++;


    //echo $a;
}


$values = $_POST['ary'];


foreach ($values as $a)
{
$query1=mysqli_query($conn,"INSERT into questiongroupword(WordAnswerQuesID,QuesGroupName,submissiondate) VALUES
('$a','$grpname','$date') ");
    echo $a;
}
header("Location:../ChoosingAssignmentType.php");
}


?>

