<?php


session_start();
session_unset();
session_destroy();
unset($_SESSION['professorLogin']);
unset($_SESSION['studentLOGIN']);
unset($_SESSION['userid']);
unset($_SESSION['username']);
unset($_SESSION['email']);

header("Location: ../index.php");


?>