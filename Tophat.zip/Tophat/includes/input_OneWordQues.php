<?php

	require 'db.inc.php';



if(isset($_POST['submitmcq']))
{
   
$result1=mysqli_query($conn,"INSERT into one_word_questions(Question,ActualAnswer,LectureTopic,submissiondate) VALUES
('$_POST[question]','$_POST[answer]','$_POST[lecture]','$_POST[date]')");
$lec=$_POST["lecture"];
$date=$_POST["date"];
header("Location:../add_OneWordQues.php?lec=".$lec."&date=".$date);

}


?>

