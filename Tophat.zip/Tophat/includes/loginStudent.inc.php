<?php





if(isset($_POST['login2']))
{
	
		
	require 'db.inc.php';
	
	$emailidusers=$_POST['email1'];
	
	$password=$_POST['password1'];
	
	
	if(empty($emailidusers) || empty($password))
{
	
	header("Location: ../loginStudent.php?error=emptyfields");
	exit();
	
}

else
{
	
	$sql="SELECT * FROM studentregistration WHERE  Email=?;";
	

	$stmt=mysqli_stmt_init($conn);
	if(!mysqli_stmt_prepare($stmt,$sql))
	{
		header("Location: ../loginStudent.php?error=sqlerror");
		
		exit();
	}
	else
	{
		mysqli_stmt_bind_param($stmt,"s",$emailidusers);
		mysqli_stmt_execute($stmt);
		$result=mysqli_stmt_get_result($stmt);
			$resultcheck=mysqli_stmt_num_rows($stmt);
		
		

				header("Location: ../loginStudent.php?error=doesntexist");
		 if($row=mysqli_fetch_assoc($result))
		{
			$pwdcheck=password_verify($password,$row['Password']);
			if($pwdcheck==false)
			{
			 
				header("Location: ../loginStudent.php?error=wrongpwd");
			
		
		exit();	
			}
			
			
			else if($pwdcheck==true)
		{
				session_start();
	$_SESSION['userid']=$row['sID'];
		$_SESSION['username']=$row['Username'];
	
			$_SESSION['email']=$row['Email'];
			if(!isset($_SESSION['studentLOGIN']))
			{
			$_SESSION['studentLOGIN']=1;
			}
			
			if(isset($_SESSION['professorLogin']))
			{
				unset($_SESSION['professorLogin']);
			}
					header("Location: ../ChoosingQuestionType.php?login=LOGINSUCCESS!!");
					
					 echo' <div style="font-size:25px; text-align:center; padding:1%;" class="alert alert-success">
  <strong>You are now logged in! </strong> !</div> ';
          
					exit();
			
		}
	
		
		else
		{
			
		
				header("Location: ../loginStudent.php?error=doesntexist");
		
		exit();
	# code...



		
				
		}
		
			
			
		}
		
		
		
	}
	
}

}	
	else
	{
		header("Location: ../loginStudent.php?");
		exit();
		
		
		
	}
	
	
	











	
	











