<?php

	require 'db.inc.php';



if(isset($_POST['submitmcqa']))
{
   
$result1=mysqli_query($conn,"INSERT into assignment_one_word_questions(Question,ActualAnswer) VALUES
('$_POST[question]','$_POST[answer]')");
$TYPE="";
if(isset($_GET["type"]))
{
	$TYPE=$_GET["type"];
}

header("Location:../add_OneWordQuesAssignment.php?type=$TYPE");





}


?>

