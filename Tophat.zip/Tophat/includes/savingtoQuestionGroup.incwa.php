<?php

	require 'db.inc.php';



if(isset($_POST['submitmcq']))
{
   

   if($_POST["questiongroup"]=="")
   {
       $grpname=$_POST["existing"];
   }
   else {
   $grpname=$_POST["questiongroup"];
	# code...
}




$values = $_POST['ary'];


foreach ($values as $a){
$result2=mysqli_query($conn,"INSERT into questiongroupword(WordAnswerQuesID,QuesGroupName) VALUES
('$a','$grpname') ");
    //echo $a;
}
/*
$values2 = $_POST['ary2'];
$no=1;
foreach ($values2 as $a2){
$result2=mysqli_query($conn,"INSERT into questiongroupmcq(MCQQuesID,QuesGroupName,QuestionNumber) VALUES
('$a2','$grpname',$no) ");
$no++;


    //echo $a;
}

}

*/

header("Location:../ChoosingAssignmentType.php");
}
?>

