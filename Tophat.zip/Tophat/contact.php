﻿<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CS 355 Contact</title>
  <style>
     h1{
    
        color: black;
       
     }
     p{
        color: black;
     }
  </style>
</head>
<?php 
session_start();
include 'tabled.php';
?>
<body>

   <!-- NAVBAR BEGINS HERE-->
  <div style="text-align:center;margin-top:20%;margin-left:12%;">
   <h3>For all contacts, please reach out via email below:</h3>
   <br>
   <p>
     <a id="email" href="mailto:mohammed.rahat85@gmail.com">mohammed.rahat85@gmail.com</a>
   </p>
</div>
</body>
</html>