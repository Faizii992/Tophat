
<?php
    session_start();
	require 'includes/db.inc.php';
    $ques_no=1;
    $lecture_topic="";
       if(isset($_GET['lecturetopic']))
    {
    $lecture_topic=(string)$_GET['lecturetopic'];
	}
      if(isset($_GET['n']))
    {
    $ques_no=(int)$_GET['n'];
	}
	
  

 

?>



<style>
.form-horizontal
{
    
}

input
{
    font-size:40px;
}


</style>





<!doctype html>

<html>

<head>
<title>
Instructions 
</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="css/bootstrap.min.css">
 
<link rel="stylesheet" href="css/header.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <?php 
    include 'tabled.php';
?>
<style>
p{
    margin-bottom:2%;
}
img
{
    margin-top:7%;
    margin-bottom:2%;
}
@media only screen and (max-width: 590px) {
  .content
  {
  margin-top:30%;
  margin-left:0%;
 
  }

  img
  {
      margin-bottom:10%;
  }
  }

 

   @media only screen and (min-width: 750px) {
  .content
  {
  margin-top:8%;
  margin-left:0%;
 
  }

   img
  {
      margin-bottom:10%;
  }
  }

     @media only screen and (min-width: 950px) {
  .content
  {
  margin-top:4%;
  margin-left:20%;
 
  }
  }
  img
  {
      margin-bottom:2%;
  }

</style>
</head>

<body>
<div class="content">
<div class="container" style="text-align:center;" >
<div class="row">

<div class="col-md-6">
<img src="images/step1.jpg" style="transform:scale(0.8)">
<p>1)Select <b>Submit</b> after typing every answer.Otherwise your answer won't be counted and will be regarded as an empty answer </p>
</div>
<div class="col-md-6">
<img src="images/step2.jpg">
<p>2)Select <b>Calculate Grade</b> after finishing your quiz inorder to calculate your grade and see the final result.</p>
</div>
<div class="col-md-12">
<img src="images/step5.jpg">
<p>3)<b>Answer in just one word.</b> Don't worry about Upper and Lower cases. Just make sure that your <b>spelling is alright</b>. Your answer will be counted as a wrong answer for redundant answers. </p>
</div>
<div class="col-md-6">
<img src="images/step3.jpg">
<p>Your answers will be finalized and you can't change your answers once you click the <b>"SUBMIT"</b> button as mentioned earlier</p>
</div>
<div class="col-md-6">
<img src="images/step4.jpg">
<p>You'll receive the following errors if you attempt to submit your answers again once it has been finalized</p>
</div>
<hr>
</div>
</div>

	</div>		          
</body>
<?php //include 'footer.php'; ?>
</html>
