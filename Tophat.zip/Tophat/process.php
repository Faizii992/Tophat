<?php
    session_start();
	require 'includes/db.inc.php';
	
	?>





	<?php
	if(!isset($_SESSION['mcq_score']))
	{
		$_SESSION['mcq_score']=0;
	}
	if(isset($_POST['submitAnswers']))
	{
        
	 $lecture_topic=(string)$_GET['lecturetopic'];
		$number=$_POST["questionnumber"];
		$SelectedChoice=$_POST["studentschoice"];
		$next=$number+1;
	if(isset($_GET["date"]))
    {
     $date=$_GET["date"];
	}
	$QID=$_GET["id"];

   // echo'<h1>'.$SelectedChoice.' <h1>';
   
       
        

		
$result=mysqli_query($conn,"SELECT * from mcq_choices Where QuestionNumber = $QID and Is_Correct = 1 and LectureTopic Like '$lecture_topic'");
$row= mysqli_fetch_assoc($result);
$correct_choice=$row['AnsID'];
if($correct_choice==$SelectedChoice)
{
	$_SESSION['mcq_score']++;
}

$result2=mysqli_query($conn,"SElect * from mcq_questions where LectureTopic Like '$lecture_topic'");
if($result2)
{
	$Row_Count=mysqli_num_rows($result2);
	$total=$Row_Count;
}

$result3=mysqli_query($conn,"SElect Textt from mcq_choices where AnsID = $SelectedChoice");
$studentchoicerow= mysqli_fetch_assoc($result3);
$studentchoicetext=$studentchoicerow['Textt'];
   
$result4=mysqli_query($conn,"SElect Textt from mcq_choices where AnsID = $correct_choice");
$correctchoicerow= mysqli_fetch_assoc($result4);
$correctchoicetext=$correctchoicerow['Textt'];


 if (isset($_SESSION["answersmcq"]))
 {
				
                $countt = count($_SESSION["answersmcq"]);
                $item_arr = array(
				
                   'Qid' => $_GET["id"],
                    'ActualAnswer' => $correctchoicetext,
                    'Answer' => $studentchoicetext,
                     'Lecture' => $lecture_topic,
                     'Status' => "",
                     'Question' => $_POST["questiontext"],
                     'date' =>date("Y-m-d"),
                     'day' =>date("l"),
                       
                      
                );
	
				
                $_SESSION["answersmcq"][$countt] = $item_arr;
  }
  else {
	# code...

$item_arr = array(
				
                   'Qid' => $_GET["id"],
                    'ActualAnswer' => $correctchoicetext,
                    'Answer' => $studentchoicetext,
                     'Lecture' => $lecture_topic,
                     'Status' => "",
                     'Question' => $_POST["questiontext"],
                       'date' =>date("Y-m-d"),
                     'day' =>date("l"),
                       
                      
                );
	
				
                $_SESSION["answersmcq"][0] = $item_arr;
                }
           
 
if($number==$total)
{
header("Location: MCQfinal.php?LectureTopic=".$lecture_topic);
}
else{
header("Location: AnswerMCQ2.php?n=".$next."&lecturetopic=".$lecture_topic."&date=".$date);

}
}

?>


	