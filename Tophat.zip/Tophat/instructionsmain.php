
<?php
    session_start();
	require 'includes/db.inc.php';
   

 

?>


<style>
.form-horizontal
{
    
}

input
{
    font-size:40px;
}


</style>





<!doctype html>

<html>

<head>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<link rel="stylesheet" href="css/bootstrap.min.css">
  <title>Choose Item to Add</title>
<link rel="stylesheet" href="css/header.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <style>
body {
  font-family: Arial, Helvetica, sans-serif;
}



.navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

@media only screen and (min-width: 992px) {
 
  

  .alert-class{
      margin-left:35%;

  }
  .alert
  {
      width:700px;
  }
  .section
  { margin-top:7%;
      margin-left:25%;
  }
 

     }

     @media only screen and (max-width: 992px) {
 
  

  .alert-class{
  margin-top:20%;
     

  }
  .section
  {margin-top:25%;
      
  }


     }
 
     
</style>
</head>

<body>



<?php 
    include 'tabled.php';
?>
<?php
if(isset($_SESSION['professorLogin']))
{

?>


  <div class="section">
                   <div class="container">
    <div class="row" >
     <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">Rules for <br>MCQ + Word Answer Based Questions</strong>
                                    </div>
                                    <div class="card-body " style="background:#3EB489;">
                                        <p class="card-text text-light">Click the button below to see the rules for adding MCQ + Word Answer Based Questions </p>
                                          <div class="text">
                                               
                                                   
                                                  <a href="instructions1.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="color:black;background-color:white; margin-top:5%;">View Instructions</a>
                                                   


                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title" style="color:white;">Rules for <br>MCQ <br>Based Questions</strong>
                                    </div>
                                    <div class="card-body" style="background:#CDE2BB;">
                                        
                                                    <p class="card-text ">Click the button below to see the rules for adding Multiple Choice Questions
                                        </p>
                                                     <a href="instructions2.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:black;color:white;">View Instructions</a>
                                            </div>
                                    </div>

                              


                            </div>
                               <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">Rules for <br>Word Answer<br> Based Questions</strong>
                                    </div>
                                    <div class="card-body " style="background:#3EB489;">
                                        <p class="card-text text-light">Click the button below to see the rules for adding Word Answer Based Questions </p>
                                          <div class="text">
                                               
                                                   
                                                  <a href="instructions3.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="color:black;background-color:white; margin-top:5%;">View Instructions</a>
                                                   


                                            </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            </div>
                           


<?php
}

else {
	 echo '
     <div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%;margin-top:5%"; class="alert alert-danger">
  <strong>You need to be have a Professor Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%;margin-top:3%"; class="alert alert-success">
  <strong>Sign up using a Professor or Student account</strong><a href="Signup_sharedview.php">HERE</a></div> 
  </div>
  ';
}

?>
			
			          
</body>
<?php //include 'footer.php'; ?>
</html>
