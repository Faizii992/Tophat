<!DOCTYPE html>
<html lang="en">
<?php

include 'includes/db.inc.php';

session_start(); 
unset($_SESSION['mcq_score']);

?>

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  

    <!-- Title Page-->
    <title>Grade Sheet</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <style>
    body{
     margin:0px;
	}
   @media only screen and (max-width: 993px) {
  .w3-container {
    visibility:hidden;
    display:none;
  }
   #tb
  {
      margin-top:15%;
  }

   @media only screen and (max-width: 739px) {
  .w3-container {
    visibility:hidden;
    margin:0px;
    padding:-10px;
    display:none;
  }
  #tb
  {
      margin-top:15%;
  }
   }



    </style>
</head>

<body class="animsition">


<div class="w3-container" style="width:100%;padding-left:0%;padding-right:0%;padding-top:0%;text-align:center;margin:0px;position:fixed;top:0px;z-index:3;">

  <div class="w3-bar w3-black" style="padding:2%;margin:0px;text-align:center;">
   
   <a href="index.php" class="w3-bar-item w3-button">Home</a>
   <a href="AssignmentTable.php" class="w3-bar-item w3-button"><i class="fas fa-check-square"></i>Assignments</a>
   <?php
   if(isset($_SESSION['studentLOGIN']))
    {
     echo '<a href="GradeSheet.php" class="w3-bar-item w3-button">Grade Book <i class="fa fa-file-text"></i></a>';
	}
    ?>

      

    <div class="w3-dropdown-hover">
      <button class="w3-button">ABOUT</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">    
              
               
                   <a class="w3-bar-item w3-button" href="developer.php">About The Developer</a>
                   <a class="w3-bar-item w3-button" href="contact.php">Contact</a>
      </div>
    </div>

       <div class="w3-dropdown-hover">
      <button class="w3-button">COURSE</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a class="w3-bar-item w3-button" href="https://www.zybooks.com/" target="_blank">ZyBooks</a>
       <a class="w3-bar-item w3-button" href="https://tophat.com/" target="_blank">TopHat</a>
       <a class="w3-bar-item w3-button" href="https://drive.google.com/drive/folders/1co7vzY9_75cCiuNTHXCGf3pKbpf_TTwC" target="_blank">Course Google Drive</a>
       <a class="w3-bar-item w3-button" href="https://www.w3schools.com/" target="_blank">W3Schools</a>

      </div>
    </div>

    
    <?php

    if(isset($_SESSION['userid']))
    {
    
	?>
        <div class="w3-dropdown-hover">
      <button class="w3-button"><b>MY ACCOUNT </b><i class="fas fa-caret-down"></i></button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4" style="min-width:260px;">
     <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img style="width:50px;"  src="images/login.png" alt="John Doe" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                <?php
                                                echo'
                                                    <h5 class="name">
                                                        <a href="#">'.$_SESSION["username"].'</a>
                                                    </h5> ';
                                                    ?>
                                                    <?php
                                                   echo' <span class="email">'.$_SESSION["email"].'</span> ';
                                                   ?>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account
                                                    </a>
                                                </div>
                                               
                                            </div>
                                            
                                             <div class="account-dropdown__footer">
                                                <a href="includes/logout.inc.php">
                                                    <i class="zmdi zmdi-power"></i>Logout
                                                </a>
                                            </div>
                                        </div>  
                                        
                                      
        

    </div>

     <?php
                                        }
                                        ?>
    
 <?php
 if(isset($_SESSION['professorLogin'])||isset($_SESSION['studentLOGIN']))
 {
  ?>
 <form action="includes/logout.inc.php">
 <button class="w3-bar-item w3-button" style="color:white;" type="submit" name="logout">LOGOUT <i class="fas fa-sign-out-alt" aria-hidden="true"></i></button>
 </form>
 
 <?php
 
 }
 else {
  echo ' <a class="w3-bar-item w3-button" href="Signup_sharedview.php"> SIGNUP </a> 
  <div class="w3-dropdown-hover">
      <button class="w3-button"><i class="fas fa-sign-in-alt"> </i> Sign in</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="loginStudent.php" class="w3-bar-item w3-button">As a Student</a>
        <a href="loginTeacher.php" class="w3-bar-item w3-button">As a Professor</a>
     

      </div>
    </div>
    ';
   // echo ' <a class="w3-bar-item w3-button" href="Signup_sharedview.php"><i class="fas fa-sign-in-alt"> </i> SIGN IN </a> ';
	# code...
}

 ?>
  <a class="w3-bar-item w3-button" href="https://www.youtube.com/watch?v=2uloZRSMkM8&feature=youtu.be">Help</a>


  </div>
</div>



<body style="background-color:#f4f4f4;" class="animsition">
<?php 
    // include 'header.php';
?>
    
        <!-- HEADER MOBILE-->

       
        <header class="header-mobile d-block d-lg-none" style="margin-top:0%;">
            <div class="header-mobile__bar" style="background-color:black;">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/logo.png" alt="tophatlogo" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">

                    <li class="active">
                            <a href="index.php">
                                <i class="fas fa-tachometer-alt"></i>HOME PAGE
                            </a>
                        </li>
                 <?php    
                     if(isset($_SESSION['studentLOGIN']))
    {
    ?>
     <li>
     <a href="GradeSheet.php" ><i class="fa fa-file-text"></i>Grade Book </a>
     </li>
     <?php
	}
    ?>

                         <?php 
                    if(isset($_SESSION['professorLogin']))
                    {
   				
                    ?>
                            <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-table"></i>ADD NEW ITEMS
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                              
                                <li>
                                    <a href="addMCQ.php"><i class="fas fa-plus-circle"></i>Add MCQ Questions</a>
                                </li>
                                <li>
                                     <a href="ProfessorAddQuesLec.php"><i class="fas fa-plus-circle"></i>Add One Word Question Answers</a>
                                </li>
                                 <li>
                                    <a href="addMCQ.php"><i class="fas fa-plus-circle"></i>Add MCQ Questions</a>
                                </li>
                                
                                 <li>
                                    <a href="ChoosingAssignmentType.php"><i class="fas fa-plus-circle"></i> Add Assignments</a>
                                </li>
                            </ul>
                        </li>

                        <?php
                        
                        
						}

                        ?>
                         <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-calendar-alt"></i>WORD ANSWER + MCQ
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">

                             <?php
                            $QuestionQueryResult=mysqli_query($conn,"select Distinct QuesGroupName FROM questiongroupmcq");


                 while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	                          {	

                            ?>
                                <li>
                                    <a href="AnswerMCQ2Assignment.php?groupname=<?php echo $Questionrow["QuesGroupName"];?>"><?php echo $Questionrow["QuesGroupName"]; ?> </a>

                                </li>
                                
                               <?php 
                                }
                                ?>
                               
                            </ul>
                        </li>
                        
                            <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-calendar-alt"></i>Multiple Choice Questions
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">

                             <?php
                            $QuestionQueryResult=mysqli_query($conn,"select Distinct LectureTopic FROM mcq_questions");


                 while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	                          {	

                            ?>
                                <li>
                                    <a href="AnswerMCQ2.php?lecturetopic=<?php echo $Questionrow["LectureTopic"];?>"><?php echo $Questionrow["LectureTopic"]; ?> </a>

                                </li>
                                
                               <?php 
                                }
                                ?>
                               
                            </ul>
                        </li>

                        
                            <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-copy"></i>One Word Question Answers
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">

                             <?php
                            $QuestionQueryResult=mysqli_query($conn,"select Distinct LectureTopic FROM one_word_questions");


                 while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	                          {	

                            ?>
                                <li>
                                    <a href="Answer_OneWordQuesBa.php?lecturetopic=<?php echo $Questionrow["LectureTopic"];?>"><?php echo $Questionrow["LectureTopic"]; ?> </a>

                                </li>
                                
                               <?php 
                                }
                                ?>
                               
                            </ul>
                        </li>

                      
                       
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-desktop"></i>Admin Information
                            </a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">

                                
                                <li>
                                    <a  href="developer.php"><i class="fas fa-table"></i>About the developer</a>
                                </li>
                                 <li>
                                    <a  href="contact.php"><i class="fas fa-table"></i>Contact Information</a>
                                </li>

                     
                      
                        
                        
			

                    </ul>
                </div>
            </nav>
            <?php
            if(isset($_SESSION['userid']))
            {
            
			
            ?>
             <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu" style="float:right;">
                                        <div class="image">
                                            <img src="images/login.png" alt="<?php echo $_SESSION['username']; ?>" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">MY ACCOUNT</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="images/login.png" alt="<?php echo $_SESSION['username']; ?>" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo $_SESSION['username']; ?></a>
                                                    </h5>
                                                    <span class="email"><?php echo $_SESSION['email']; ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account
                                                    </a>
                                                </div>
                                               
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="includes/logout.inc.php">
                                                    <i class="zmdi zmdi-power"></i>Logout
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                }
                                else{


                                ?>

                                 <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu" style="float:right;">
                                       
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">SIGN IN</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                           
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="loginTeacher.php">
                                                        <i class="zmdi zmdi-account"></i>As a Professor
                                                    </a>
                                                </div>
                                               
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="loginStudent.php">
                                                        <i class="zmdi zmdi-account"></i>As a Student
                                                    </a>
                                                </div>
                                               
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="Signup_sharedview.php">
                                                    <i class="zmdi zmdi-power"></i>Sign Up
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php
								}
                                ?>
        </header>
        </div


        <?php 
        if(isset($_SESSION['studentLOGIN']))
        {
          $userid=$_SESSION['userid'];
		?>
      
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
       <?php
       $R1=mysqli_query($conn,"select * FROM awarevstat where sid= $userid");
$rc1=mysqli_num_rows($R1);
    $R2=mysqli_query($conn,"select * FROM mcqrevstat where sid= $userid");
$rc2=mysqli_num_rows($R2);
$R3=mysqli_query($conn,"select * FROM warevstat where sid= $userid");
$rc3=mysqli_num_rows($R3);
if(($rc1==0)&&($rc2==0)&&($rc3==0))
{
    echo '<div style="font-size:20px; text-align:center; padding:1%;margin-top:10%"; class="alert alert-danger">
  <strong>There is nothing to show!</strong><br>You did not take any quiz!<br><a href="AssignmentTable.php"><u>Check your Assignments using this link.</u></a></div> ';
}
else {
	# code...


       ?>
            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
               
                                <div id="tb" class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                
                                                <th><b>DATE   TAKEN</b></th>
                                                <th><b>Title</b></th>
                                                <th><b>Answer</b></th>
                                                <th><b>Total Points</b></th>
                                                <th><b>status</b></th>
                                      
                                                
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                        
                                                  
                                                  <?php
                                             
$Result=mysqli_query($conn,"select * FROM awarevstat where sid= $userid");
$rowcount=mysqli_num_rows($Result);
if($rowcount>0)
{


while($qRow=mysqli_fetch_array($Result))
{    $lecc="";
$qid=$qRow["waquesid"];
$lecc=$qRow["lecturetopic"];


                                              ?>

                                               <tr class="tr-shadow">
                                                <td><?php echo $qRow["daytaken"].'  '.$qRow["datetaken"]; ?> </td>
                                                <td>
                                                    <span class="block-email"><?php echo $qRow["lecturetopic"]; ?></span>
                                                </td>
                                              
                                        <?php 
                                        
                                        
                                        $lecc=$qRow["lecturetopic"]; ?>
                                                <td>
                                                
                                                <a href="teststat3.php?lecc=<?php echo $lecc; ?>&id=<?php echo $userid; ?>" style="color:white;" class="btn btn-secondary mb-1"  data-lec="<?php echo $lecc; ?>" data-toggle="modal" data-target="#scrollmodal">
											<i class="mr-2 fa fa-align-justify"></i>Show Content
										</a></td>
                                        <?php
                                        $result=mysqli_query($conn,"select * FROM amcqresultrev where lecturetopic LIKE '$lecc' and  sid=$userid");
$rowcount=mysqli_num_rows($result);

   $resultt=mysqli_query($conn,"select * FROM awaresultrev where lecturetopic LIKE '$lecc' and  sid=$userid");
$rowcountt=mysqli_num_rows($resultt);
$rowcount+=$rowcountt;
                     $rslt=mysqli_query($conn,"select * FROM amcqresultrev where lecturetopic LIKE '$lecc' and  sid=$userid and status LIKE 'Correct'");
$rc=mysqli_num_rows($rslt);

   $rslt2=mysqli_query($conn,"select * FROM awaresultrev where lecturetopic LIKE '$lecc' and  sid=$userid and status LIKE 'Correct'");
$rcc=mysqli_num_rows($rslt2);
$rc+=$rcc;


                                        ?>

                                                <td><?php echo $rc.'/'.$rowcount?></td>
                                                <td>
                                                    <span class="status--process">Finished</span>
                                                </td>
                                              
                                             
                                            </tr>

                                               <tr class="spacer"></tr>
                                        <?php

                                        }
                                        }
                                         else    { /*echo 
                                         '
                                        
                                         <p style="text-align:center;">THERE IS NOTHING TO SHOW ON THE TABLE </p>
                                         ';
	# code...
                                                */}
                                       

                                        ?>

                                              <?php
                                              $userid=$_SESSION["userid"];
$QuestionQResult=mysqli_query($conn,"select * FROM mcqrevstat where sid= $userid");
$rowcount=mysqli_num_rows($QuestionQResult);
if($rowcount>0)
{


while($QRow=mysqli_fetch_array($QuestionQResult))
{    $lecc="";
$qid=$QRow["mcqquesid"];
$lecc=$QRow["lecturetopic"];


                                              ?>

                                               <tr class="tr-shadow">
                                                <td><?php echo $QRow["daytaken"].'  '.$QRow["datetaken"]; ?> </td>
                                                <td>
                                                    <span class="block-email">Multiple Choice Questions</span>
                                                </td>
                                              
                                        <?php 
                                        
                                        
                                        $lecc=$QRow["lecturetopic"]; ?>
                                                <td>
                                                
                                                <a href="teststat.php?lecc=<?php echo $lecc; ?>&id=<?php echo $userid; ?>" style="color:white;" class="btn btn-secondary mb-1"  data-lec="<?php echo $lecc; ?>" data-toggle="modal" data-target="#scrollmodal">
											<i class="mr-2 fa fa-align-justify"></i>Show Content
										</a></td>

                                                <td><?php echo $QRow["totalpoints"].'/'.$QRow["totalquesno"]; ?></td>
                                                <td>
                                                    <span class="status--process">Finished</span>
                                                </td>
                                              
                                             
                                            </tr>

                                               <tr class="spacer"></tr>
                                        <?php

                                        }
                                        }
                                         else    { /*echo 
                                         '
                                        
                                         <p style="text-align:center;">THERE IS NOTHING TO SHOW ON THE TABLE </p>
                                         ';
	# code...
                                                */}
                                       

                                        ?>

                                         <?php
                                              $userid=$_SESSION["userid"];
$QResult=mysqli_query($conn,"select * FROM warevstat where sid= $userid");
$rowcount=mysqli_num_rows($QResult);
if($rowcount>0)
{


while($qRow=mysqli_fetch_array($QResult))
{    $lecc="";
$qid=$qRow["waquesid"];
$lecc=$qRow["lecturetopic"];


                                              ?>

                                               <tr class="tr-shadow">
                                                <td><?php echo $qRow["daytaken"].'  '.$qRow["datetaken"]; ?> </td>
                                                <td>
                                                    <span class="block-email">Word Answers</span>
                                                </td>
                                              
                                        <?php 
                                        
                                        
                                        $lecc=$qRow["lecturetopic"]; ?>
                                                <td>
                                                
                                                <a href="teststat2.php?lecc=<?php echo $lecc; ?>&id=<?php echo $userid; ?>" style="color:white;" class="btn btn-secondary mb-1"  data-lec="<?php echo $lecc; ?>" data-toggle="modal" data-target="#scrollmodal">
											<i class="mr-2 fa fa-align-justify"></i>Show Content
										</a></td>

                                                <td><?php echo $qRow["totalpoints"].'/'.$qRow["totalquesno"]; ?></td>
                                                <td>
                                                    <span class="status--process">Finished</span>
                                                </td>
                                              
                                             
                                            </tr>

                                               <tr class="spacer"></tr>
                                        <?php

                                        }
                                        }
                                         else    { /*echo 
                                         '
                                        
                                         <p style="text-align:center;">THERE IS NOTHING TO SHOW ON THE TABLE </p>
                                         ';
	# code...
                                                */}
                                       

                                        ?>
                                            
                                        </tbody>
                                    </table>

                                </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                       
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>

        <?php
        }

        }
  

        ?>

   

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
