
<?php
    session_start();
	require 'includes/db.inc.php';
    $ques_no=1;
    $lecture_topic="";
       if(isset($_GET['lecturetopic']))
    {
    $lecture_topic=(string)$_GET['lecturetopic'];
	}
      if(isset($_GET['n']))
    {
    $ques_no=(int)$_GET['n'];
	}

    $grpname="";
       if(isset($_GET['groupname']))
    {
    $grpname=(string)$_GET['groupname'];
	}
	
  

 

?>

<!doctype html>

<html>

<head>
<title>
Multiple Choice Test
</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<link rel="stylesheet" href="css/bootstrap.min.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <?php 
    include 'tabled.php';
?>

<style>
 @media only screen and (max-width: 709px) {
  .content
  {
  margin-top:25%;
  }

 
   .alert-class
  {
  margin-top:18%;
  }
  }

   @media only screen and (min-width: 905px) {
  .content
  {
  margin-top:5%;
  margin-left:13%;
  }

  .alert{
  margin-left:32%;
  width:680px;
  
  }

   .alert-class
  {
  margin-top:8%;
  }
  }

   @media only screen and (min-width: 760px) {
  .content
  {
  margin-top:5%;
  margin-left:13%;
  }

  .alert-class
  {
  margin-top:8%;
  }
 
  }

</style>
</head>

<body>

<?php
if(isset($_SESSION['studentLOGIN']))
{
$SID=$_SESSION['userid'];
$QQResult=mysqli_query($conn,"select * FROM amcqrevstat where sid=$SID and lecturetopic Like '$grpname'");

$check=mysqli_num_rows($QQResult);
if($check>0)
{echo '<div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%"; class="alert alert-danger">
  <strong>You have already taken this quiz!</strong></div> 
  <div style="font-size:20px; text-align:center; padding:1%"; class="alert alert-success">
  <strong><a id="takelec" href="GradeSheet.php" > YOU CAN FIND ALL YOUR TEST RESULTS IN YOUR GRADEBOOK</a></strong></div>
  
  </div>
  ';
  

}
else
{




?>
    <div class="content">
<h3 style="text-align:center; margin-top:2%;text-transform:Uppercase"> <b> Choose the Correct option </b></h3> 
<?php
$queryResult3=mysqli_query($conn,"SELECT * from questiongroupmcq where QuesGroupName LIKE '$grpname'");
    if($queryResult3)
    {
     $RowCount=mysqli_num_rows($queryResult3);
        $total_ques=$RowCount;
        

	}
 ?>
<p style="text-align:center"> Question <?php echo $ques_no; ?> of <?php echo $total_ques; ?>  </p>
<?php

$Questiongroup=mysqli_query($conn,"select MCQQuesID FROM questiongroupmcq where QuesGroupName LIKE '$grpname' and QuestionNumber = $ques_no");
$QuestiongroupRow=mysqli_fetch_array($Questiongroup);
$grouprow=$QuestiongroupRow["MCQQuesID"];

$Questionquery=mysqli_query($conn,"select * from assignment_mcq_questions WHERE QuestionID= $grouprow");
$QuestionRow=mysqli_fetch_array($Questionquery);
$QID= $QuestionRow["QuestionID"];
$AnsQueryResult=mysqli_query($conn,"select * FROM assignment_mcq_choices where QuestionNumber LIKE '$QID'");

echo ' <h1 style="color:green; text-align:center;">' .$QuestionRow["Textt"] . '?</h1>';
while($AnswerRows=mysqli_fetch_array($AnsQueryResult))
	{	

?>


  <div class="container col-md-12">
   <center>

  <form class="form-horizontal" action="processAssignment.php?id=<?php echo $QID;?>&groupname=<?php echo $grpname; ?>" method="post">



      <input type="hidden" name="questionnumber" value="<?php echo $ques_no; ?>">  
       <input type="hidden" name="questiontext" value="<?php echo $QuestionRow["Textt"]; ?>"> 
        <input type="hidden" name="questionID" value="<?php echo $QID; ?>">  
    <label class="radio">
      <input value="<?php echo $AnswerRows["AnsID"]; ?>" type="radio" name="studentschoice"> <?php echo $AnswerRows["Textt"] ?>
    </label>
  
       
  </center>

<?php 

}
?>
  <button type="submit" id="submitAnswers" name="submitAnswers"
     style="font-size:15px; padding:0.4% 2%; margin:auto; display:block;"  class="btn btn-success">Submit Answer</button>
        <button type="submit" id="submitAnswers" name="comp"
    
   
  </form>
  <?php
}
}
else {
	 echo '
     <div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%"; class="alert alert-danger">
  <strong>You need to be have a Student Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%;" class="alert alert-success">
  <strong>Sign up using a Professor or Student account</strong><a href="Signup_sharedview.php">HERE</a></div> 
  </div>
  ';
}

?>   
 </div>
			          
</body>
<?php //include 'footer.php'; ?>
</html>
