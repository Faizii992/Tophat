

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">

     <title>CS355 Home page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" type="text/css" href="css/sourcesanspro-font.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
 <style>
    body{
     margin:0px;
	}
   @media only screen and (max-width: 693px) {
  .section{
    margin-left:0%;
    margin-top:25%;
  }
  }

   @media only screen and (min-width: 700px) {
  .section{
    margin-left:0%;
    margin-top:15%;
    
  }
  }

   @media only screen and (min-width: 800px) {
 
  .section
  {
     margin-left:25%;
  }

     }

       @media only screen and (min-width: 1000px) {
 
  .section
  { margin-top:5%;
     margin-left:35%;
  }

  .col-lg-5
  {
      margin-right:4%;
  }

     }

     @media only screen and (min-width: 1025px) {
 
  .section
  { margin-top:5%;
     margin-left:25%;
  }

  .col-lg-5
  {
      margin-right:4%;
  }
  .alert
  {
      width:800px;
      margin-left:5%;
  }

     }

   

    </style>
</head>

    <?php
    session_start();
    if(isset($_SESSION["userid"]))
    {
      include 'tabled.php';
      ?>
      <style>
         @media only screen and (min-width: 1023px) {
 
  .section
  { margin-top:5%;
     margin-left:30%;
  }

  .col-lg-5
  {
      margin-right:4%;
  }
  .alert
  {
      width:600px;
      margin-left:12%;
  }
  #welcome
  {
      margin-left:20%;
      margin-top:20%;
     
  }

     }
     </style>
     <?php
	}
    else {
    include 'header.php';
    ?>
        <style>
         @media only screen and (min-width: 1023px) {
 
  .section
  { margin-top:5%;
     margin-left:15%;
  }

  .col-lg-5
  {
      margin-right:4%;
  }
  .alert
  {
      width:600px;
      margin-left:12%;
  }
  #welcome
  {
      margin-left:25%;
      margin-top:10%;
  }

     }
     </style>

    <?php

    ?>


	<?php


}

  

    ?>

    <div class="section">
    <p id="welcome" style="color:black;font-size:30px;margin-bottom:2.5%;">WELCOME TO MY WEBSITE </p>
    <?php 
    if(!isset($_SESSION["userid"]))
    {
    
	
    ?>
    <div class="container">
    <div class="row" >
     <div class="col-md-5">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">LOGIN AS A TEACHER</strong>
                                    </div>
                                    <div class="card-body " style="background:#3EB489;">
                                        <p class="card-text text-light">Signup as teacher using the button below </p>
                                          <div class="text">
                                               
                                                   
                                                  <a href="signupTeacher.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="color:black;background-color:white; margin-top:5%;">Sign up as a Teacher </a>
                                                    <p style="color:white; margin-top:7%;margin-bottom:1%;"><b>Already Have an Account?</b></p>
                                                    <p class="card-text text-light">Login as a teacher using the button below 
                                        </p>
                                                     <a href="loginTeacher.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:black;color:white;">Login as a Teacher </a>


                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title" style="color:white;">LOGIN AS A STUDENT</strong>
                                    </div>
                                    <div class="card-body" style="background:#CDE2BB;">
                                        <p class="card-text ">Signup as student using the button below 
                                        </p>
                                         <div class="text">
                                          
                                                
                                                    <a href="signupStudent.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:white;color:black; margin-top:5%;">Sign up as a Student </a>
                                                    <p style="color:black; margin-top:8%;margin-bottom:1%;"><b>Already Have an Account?</b></p>
                                                    <p class="card-text ">Login as a student using the button below 
                                        </p>
                                                     <a href="loginStudent.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:black;color:white;">Login as a Student </a>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            </div>

                            <?php
                            }
                            ?>
    
</div>



</body>
</html>