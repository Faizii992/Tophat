
<?php
    session_start();
	require 'includes/db.inc.php';
    $lecture_topic="";
if(isset($_GET['lecturetopic']))
{
$lecture_topic=(string)$_GET['lecturetopic'];
}
    

 

?>


<style>
.form-horizontal
{
    
}

input
{
    font-size:40px;
}


</style>





<!doctype html>

<html>

<head>
<title>
CS355 Student Page
</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<link rel="stylesheet" href="css/bootstrap.min.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <style>
    body{
     margin:0px;
	}

   
   @media only screen and (max-width: 693px) {
  .section{
    margin-left:0%;
    margin-top:25%;

  }
  .alert-class
      {
       margin-top:20%;
	  }
 
  }

   @media only screen and (min-width: 700px) {
  .section{
    margin-left:5%;
    margin-top:15%;
    
  }

  .col-sm-3
  {
      min-width:33%;
  }
  }

   @media only screen and (min-width: 800px) {
 
  .section
  {
     margin-left:25%;
  }

     }

     @media only screen and (min-width: 992px) {
 
  .section
  { margin-top:5%;
     margin-left:23%;
  }

  .alert-class{
      margin-left:35%;

  }
  .alert
  {
      width:700px;
  }

 

     }
     

    </style>
</head>

<body>
<?php
$msg="";
if(isset($_GET["login"]))
{
	
$msg=$_GET["login"];
}
if($msg=="LOGINSUCCESS!!")
{

?>

<script>


    $(document).ready(function(){
        $("#scrollmodal").modal('show');
    });
</script>

<?php
}

?>
<?php 
    include 'tabled.php';
?>
<?php
if(isset($_SESSION['studentLOGIN']))
{

?>

  <div class="section">
                    
                   
                        <div class="row" style="text-align:center;">
                           <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">CREATE ASSIGNMENTS</strong>
                                    </div>
                                    <div class="card-body " style="background:#FAD0C9FF;">
                                     
                                       <div class="text">
                                                <h2 style="color:white;">Answer In One Word</h2>
                                                <span>Test how much you know using these word answer questions!</span> <br>
                                                
                                                 <?php

                                                 if($lecture_topic== "")
                                                 { echo '<a href="ChoosingLectureType.php?type=wa" class="btn btn-default" style="background-color:white; margin-top:0%;">CLICK HERE </a>';
                                                 
												 }
                                                 else {
                                                 ?>
                                                 <a href="Answer_OneWordQuesBa.php?lecturetopic=<?php echo $lecture_topic; ?>"
                                                class="btn btn-default" style="background-color:white; margin-top:0%;">CLICK HERE </a>
                                                  

                                                 <?php
                                                 }
                                                 ?>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">ASSIGNMENT TYPES</strong>
                                    </div>
                                    <div class="card-body " style="background:#CDE2BB;">
                                       
                                          <div class="text">
                                                <h2 style="color:white;">Assignments</h2>
                                                <span>Take a view of all your assignments</span>
                                                 <p style="text-transform:Capitalize; color:#808080;">Finish these assignments before your deadline!</p>
                                                <br>
                                                 <a href="AssignmentTable.php?lecturetopic=<?php echo $lecture_topic; ?>" 
                                                class="btn btn-default" style="background-color:black;color:white; margin-top:0%;margin-bottom:0%;">CLICK HERE </a>
                                                 
                                               
                                                 
                                            </div>
                                       
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">INSTRUCTIONS</strong>
                                    </div>
                                    <div class="card-body " style="background:#FAD0C9FF;">
                                       
                                           <div class="text">
                                                <h2 style="color:white;">MCQ</h2>
                                                <span>Multiple Choice Questions to test your knowledge</span>
                                                <br>
                                                 <?php
                                                 if($lecture_topic=="")
                                                 { 
                 echo '<a href="ChoosingLectureType.php?type=mcq" class="btn btn-default" style="background-color:white; margin-top:5%;">CLICK HERE </a>';
                 
												 }
                                                 else {
                                                 ?>
	                                           <a href="AnswerMCQ2.php?lecturetopic=<?php echo $lecture_topic; ?>&n=1"
                                                 class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:white; margin-top:5%;">CLICK HERE </a>
                                                 
                                                 <?php
                                                     }
                                                     ?>
                                                   
                                            </div>
                                    </div>
                                </div>
                            </div>
                            
                                </div>
                            </div>
                          
                            

                          

  <?php
}

else {
	 echo '
     <div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%;margin-top:5%"; class="alert alert-danger">
  <strong>You need to be have a Student Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%;margin-top:3%"; class="alert alert-success">
  <strong>Sign up and login using a Student account </strong><a href="Signup_sharedview.php">HERE</a></div> 
  </div>
  '
  
  ;
}

?>   
 

	</div>		
				<div style="margin-top:6%;margin-left:5%;text-align:center;" class="modal fade" id="scrollmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true">
				<div class="modal-dialog modal-md" role="document">
					<div class="modal-content" style="text-align:center;text-align:center;">
						<div class="modal-header" style="background-color:#BDE2DD;">
							<h5 class="modal-title" id="scrollmodalLabel" style="color:color;text-align:center;">WELCOME!</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body" style="text-align:center;background-color:#f4f4f4;">
							<p>
								Thankyou for logging in <?php echo $_SESSION["username"]; ?>
							
							</p>
						</div>
					
					</div>
				</div>
			</div>          
</body>
<?php //include 'footer.php'; ?>
</html>
