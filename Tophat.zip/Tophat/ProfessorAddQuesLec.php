
<?php
    session_start();
	require 'includes/db.inc.php';
   

 

?>


<style>
.form-horizontal
{
    
}

input
{
    font-size:40px;
}


</style>





<!doctype html>

<html>

<head>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<link rel="stylesheet" href="css/bootstrap.min.css">
  <title>Choose Item to Add</title>
<link rel="stylesheet" href="css/header.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <style>
body {
  font-family: Arial, Helvetica, sans-serif;
}



.navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

@media only screen and (min-width: 992px) {
 
  

  .alert-class{
      margin-left:35%;
      margin-top:10%;

  }
  .alert
  {
      width:700px;
  }
  .section
  { margin-top:7%;
      margin-left:25%;
  }
 

     }

     @media only screen and (max-width: 992px) {
 
  

  .alert-class{
  margin-top:20%;
     

  }
  .section
  {margin-top:25%;
      
  }

 

     }
	 
	 
     
</style>
<?php
$msg="";
if(isset($_GET["login"]))
{
	
$msg=$_GET["login"];
}
if($msg=="LOGINSUCCESS!!")
{

?>

<script>


    $(document).ready(function(){
        $("#scrollmodal").modal('show');
    });
</script>

<?php
}

?>
</head>

<body>



<?php 
    include 'tabled.php';
?>
<?php
if(isset($_SESSION['professorLogin']))
{

?>


  <div class="section">
                    <div class="container-fluid">
                   
                        <div class="row m-t-25" style="text-align:center;">
                        <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">CREATE ASSIGNMENTS</strong>
                                    </div>
                                    <div class="card-body " style="background:#FAD0C9FF;">
                                     
                                          <div class="text">
                                             
                                                <p style="color:#808080;">Create assignments for the students</p>
                                                <p style="margin-bottom:2%; color:black;">Help the students make their concept clearer by giving them assignments </p>
                                                
                                                
                                           <a href="ChoosingAssignmentType.php" class="btn btn-default" style="background-color:black;color:white; margin-top:4%;">+ ADD ASSIGNMENTS</a>
                                                 
                                                 
                                                
                                                 
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">ASSIGNMENT TYPES</strong>
                                    </div>
                                    <div class="card-body " style="background:#CDE2BB;">
                                       
                                          <div class="text">
                                               
                                           <ul style="list-style-type:none; color:#808080;font-size:14px;">
                                                <li><i class="fas fa-check"></i>Add Questions consisting of Word Answers!</li>
                                                <li><i class="fas fa-check"></i>Add Questions consisting of Multiple Choice Questions!</li>
                                                <li><i class="fas fa-check"></i>Add Questions consisting of both word answers and Multiple Choices! </li>
                                                </ul>
                                                <p style="color:black;margin-top:4%;"> Create assignments and assign them to a group later </p>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">INSTRUCTIONS</strong>
                                    </div>
                                    <div class="card-body " style="background:#FAD0C9FF;">
                                       
                                          <div class="text">
                                               
                                                    <p style="color:#808080;"><b>There are some specific rules on how you can add new questions for creating assignments.</b></p> <p style="text-transform:Uppercase;color:black;">  It's highly suggested that you follow these instructions!.</p>
                                                 
                                                   <a href="instructionsmain.php" class="btn btn-default" style="background-color:black;color:white; margin-top:0%;">See instructions!</a>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            
                                </div>
                            </div>
                          
                           
                           


<?php
}

else {
	 echo '
     <div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%;margin-top:5%"; class="alert alert-danger">
  <strong>You need to be have a Professor Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%;margin-top:3%"; class="alert alert-success">
  <strong>Sign up using a Professor or Student account</strong><a href="Signup_sharedview.php">HERE</a></div> 
  </div>
  ';
}

?>
			<div style="margin-top:6%;margin-left:5%;text-align:center;" class="modal fade" id="scrollmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true">
				<div class="modal-dialog modal-md" role="document">
					<div class="modal-content" style="text-align:center;text-align:center;">
						<div class="modal-header" style="background-color:#BDE2DD;">
							<h5 class="modal-title" id="scrollmodalLabel" style="color:color;text-align:center;">WELCOME!</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body" style="text-align:center;background-color:#f4f4f4;">
							<p>
								Thankyou for logging in <?php echo $_SESSION["username"]; ?>
							
							</p>
						</div>
					
					</div>
				</div>
			</div>		
			          
</body>
<?php //include 'footer.php'; ?>
</html>
