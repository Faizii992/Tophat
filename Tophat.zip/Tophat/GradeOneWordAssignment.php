<?php
    session_start();
	require 'includes/db.inc.php';
     if(isset($_GET['groupname']))
    {
    $grpname=(string)$_GET['groupname'];
	}
 

?>

<style>

 body
     { 
     text-align:center;
     
     }

    
    
input[type="text"]
{
    font-size:18px;
    width:400px;
    margin:auto;
    text-align:center;
   
   
   
}

</style>




<!doctype html>

<html>

<head>

<title>
Assignment Results
</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



<link rel="stylesheet" href="css/bootstrap.min.css">
 
<link rel="stylesheet" href="css/header.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   <style>
   @media only screen and (max-width: 590px) {
  .content
  {
  margin-top:30%;
  margin-left:0%;
 
  }
    #takelec{
       margin-left:20%;
   }
  }

   @media only screen and (max-width: 490px) {
  .content
  {
  margin-top:40%;
  margin-left:0%;
 
  }

  .alert-class
  {
      margin-top:15%;
  }
   #takelec{
       margin-left:20%;
   }

  }

   @media only screen and (max-width: 990px) {
  .content
  {
  margin-top:20%;
  margin-left:0%;
 
  }
  }

   @media only screen and (max-width: 790px) {
  .content
  {
  margin-top:30%;
  margin-left:0%;
 
  }
   .alert-class
  {
      margin-top:15%;
  }
    #takelec{
       margin-left:30%;
   }

  }

   @media only screen and (min-width: 1023px) {
   .content
   {
       margin-left:25%;
   }

   .alert
   {
       width:600px;
       margin-left:14%;
   }
 

  }

     @media only screen and (min-width: 1025px) {
   .content
   {
       margin-left:25%;
   }

   .alert
   {
       width:750px;
       margin-left:10%;
   }
   #takelec{
       margin-left:35%;
   }
 

  }

</style>
</head>
<?php 
    include 'tabled.php';
?>
<body>
<div class="content">
<?php 
  if(!isset($_SESSION['answersoneword']))
  {
       echo '<div style="font-size:20px; text-align:center; padding:1%;margin-top:10%"; class="alert alert-danger">
  <strong>There is nothing to show!</strong></div> 
    <div style="font-size:20px; text-align:center; padding:1%; margin-top:2%";margin-bottom:5%; class="alert alert-success">
  <a href="GradeSheet.php"> <u>CLICK THIS LINK TO FIND ALL YOUR TEST RESULTS IN YOUR GRADEBOOK</u></a></div>
  
  '; 
    echo ' 
   <a id="takelec" href="AssignmentTable.php" style="margin-bottom:5%;padding:1% 2%;font-size:18px;margin-top:1%;" class="btn btn-success"> START TAKING QUIZZES! </a>
  '; 
  
  }
  else {
	# code...


?>
  <div class="container" style="margin-top:2%;margin-bottom:3%;text-align:center;">
   
    <h2 style="color:green;">YOUR'E DONE!</h2>
    <h3> Congrats! You have completed the test. </h3>
  <h2>RESULTS</h2>

   
</div>
 <div class="container" style="margin-top:2%;margin-bottom:0px;text-align:center;">
   
    
   <h4 style="margin-top:5%;"><u><b> ONE WORD ANSWER RESULTS</b> </u></h4>
   
</div>

<?php
  $score=0;

  ?>

 <table style="margin-top:0%;margin-bottom:2%; padding-bottom:2%;width:75%;margin-left:12%;" class="table table-striped table-bordered">
 <thead class="thead-dark">
            <tr>
                <th width="12%">QUESTION </th>
                <th width="8%">Actual Answer</th>
               
                <th width="8%">Student's Answer</th>
                
                <th width="10%">Status</th>
            </tr>
		</thead>	
			<?php
			 
   $cnt=0;
  
    $correctcnt=0;		
    $wrongcnt=0;
					
                    foreach ($_SESSION["answersoneword"] as $key => $value) {
                       $_SESSION["status"]="";

$QuestionQueryResult=mysqli_query($conn,"select * FROM assignment_one_word_questions");
$AnsQueryResult=mysqli_query($conn,"select * FROM assignment_answertablemcq");

while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	{	
    $value["Status"]="Wrong";
    if((strcasecmp($Questionrow["ActualAnswer"],$value["Answer"])==0)&&($Questionrow["Qid"]==$value["Qid"]))
    {
  
     $value["Status"]="Correct";
       $score++;
   
    break;
	}
    else {
	# code...
    
    continue;
}

    }


    $cnt++;




                    echo '<tr>
                           <td> <b>'.$value["Question"].'?</b></td> ';
							
                         echo  ' <td>'.$value["ActualAnswer"]. '</td> ';
							
                          
                            		
                            echo '<td>'.$value["Answer"].'</td>';
                           
                            



                            
if($value["Status"]=="Correct")
{ 
     $correctcnt++;
  
   
    
                          echo '   <td style="background-color:#50C878;"><b></b>'. $value["Status"] . '</td> ';

  
}
else {
$wrongcnt++;
	echo ' <td style="background-color:CA3444; color:white;"><b></b>'. $value["Status"] . '</td> ';
   
}
$stat=$value["Status"];
$ans=$value["Answer"];
$actans=$value["ActualAnswer"];
$ques=$value["Question"];
$userid=$_SESSION["userid"];
$qid=$value["Qid"];
$day=$value["day"];
$date=$value["date"];
$lecture=$value["Lecture"];
   $resultw=mysqli_query($conn,"INSERT into awaresultrev(sid,actualAnswer,studentsanswer,status,question,waquesid,lecturetopic) VALUES
('$userid','$actans','$ans','$stat','$ques','$qid','$lecture')"); 
                        
                       
                     echo '   </tr> ';
                       
                      

						 }
                       
                    
                     $resultc=mysqli_query($conn,"INSERT into awarevstat(sid,daytaken,datetaken,totalpoints,waquesid,totalquesno,lecturetopic) VALUES
('$userid','$day','$date','$correctcnt','$qid','$cnt','$lecture')");         
         echo '   </table> '; 
            


            ?>
        

    <?php
    
    ?>

      <div class="container" style="margin-top:2%;margin-bottom:0%;text-align:center;">
   
    
    <h4 style="margin-top:5%;"><u><b> MCQ RESULTS</b> </u></h4>
   
</div>
      <table id="tabled" style="margin-top:0%;margin-bottom:1%; padding-bottom:2%; width:72.5%;margin-left:12%;" class="table table-striped table-bordered">
 <thead class="thead-dark">
            <tr>
                <th width="12%">QUESTION </th>
                <th width="8%">Actual Answer</th>
               
                <th width="8%">Student's Answer</th>
                  
                <th width="10%">Status</th>
            </tr>
		</thead>	
			<?php
	$correctcnt=0;
 $cnt=0;
					
                    foreach ($_SESSION["answersmcq"] as $key => $value) {
                    $cnt++;
                       $_SESSION["status"]="";	
    $value["Status"]="Wrong";
    if(strcasecmp($value["ActualAnswer"],$value["Answer"])==0)
    {
  
     $value["Status"]="Correct";
  
    //break;
	}
    else {
     $value["Status"]="Wrong";
}

   
   
                    echo '<tr>
                          <td> <b>'.$value["Question"].'?</b></td> ';
							
                         echo  ' <td>'.$value["ActualAnswer"]. '</td> ';
                        
                            echo '<td>'.$value["Answer"].'</td>';  
                             
                          
                          
 if($value["Status"]=="Correct")
 {
 $correctcnt++;
       echo '<td style="background-color:#50C878;"><b></b>'. $value["Status"] . '</td>';
 }
 else {
	echo ' <td style="background-color:#CA3444; color:white;"><b></b>'. $value["Status"] . '</td> ';
}
$stat=$value["Status"];
$ans=$value["Answer"];
$actans=$value["ActualAnswer"];
$ques=$value["Question"];
$userid=$_SESSION["userid"];
$qid=$value["Qid"];
$day=$value["day"];
$date=$value["date"];
$lecture=$value["Lecture"];

        $resultx=mysqli_query($conn,"INSERT into amcqresultrev(sid,actualAnswer,studentsanswer,status,question,mcqquesid,lecturetopic) VALUES
('$userid','$actans','$ans','$stat','$ques','$qid','$lecture')");             


                     echo '</tr>';
                                           
       
           }
         
   $resulty=mysqli_query($conn,"INSERT into amcqrevstat(sid,daytaken,datetaken,totalpoints,mcqquesid,totalquesno,lecturetopic) VALUES
('$userid','$day','$date','$correctcnt','$qid','$cnt','$lecture')"); 
             echo '   </table> '; 
             ?>
               <div class="container" style="margin-bottom:3%;text-align:center;">
   
   <h2> Final Score : <?php echo $correctcnt+$score; ?> </h2>
    <a href="AssignmentTable.php" style="margin-bottom:5%;padding:1% 2%;font-size:18px;margin-top:1%;" class="btn btn-success"> TAKE MORE QUIZZES! </a>
 
     <hr>
</div>
<?php
            } ?>
          
    </div>
    </div>

  <?php
  unset($_SESSION['mcq_score']);
unset($_SESSION['answersmcq']);
unset($_SESSION['answersoneword']);
  ?>
</body>

</html>
