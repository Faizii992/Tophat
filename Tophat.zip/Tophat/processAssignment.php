<?php
    session_start();
	require 'includes/db.inc.php';
	
	?>





	<?php
	if(!isset($_SESSION['mcq_score']))
	{
		$_SESSION['mcq_score']=0;
	}
	if(isset($_POST['submitAnswers']))
	{
        
	 $lecture_topic=(string)$_GET['lecturetopic'];
		$number=$_POST["questionnumber"];
		$SelectedChoice=$_POST["studentschoice"];
		$next=$number+1;
	
	$QID=$_GET["id"];
    if(isset($_GET["date"]))
    {
     $date=$_GET["date"];
	}
   // echo'<h1>'.$SelectedChoice.' <h1>';
   
        $grpname="";
       if(isset($_GET['groupname']))
    {
    $grpname=(string)$_GET['groupname'];
	}
        

		
$result=mysqli_query($conn,"SELECT * from assignment_mcq_choices Where QuestionNumber = $QID and Is_Correct = 1 ");
$row= mysqli_fetch_assoc($result);
$correct_choice=$row['AnsID'];
if($correct_choice==$SelectedChoice)
{
	$_SESSION['mcq_score']++;
}

$result2=mysqli_query($conn,"SElect * from questiongroupmcq where QuesGroupName LIKE '$grpname'");
if($result2)
{
	$Row_Count=mysqli_num_rows($result2);
	$total=$Row_Count;
}

$result3=mysqli_query($conn,"SElect Textt from assignment_mcq_choices where AnsID = $SelectedChoice");
$studentchoicerow= mysqli_fetch_assoc($result3);
$studentchoicetext=$studentchoicerow['Textt'];
   
$result4=mysqli_query($conn,"SElect Textt from assignment_mcq_choices where AnsID = $correct_choice");
$correctchoicerow= mysqli_fetch_assoc($result4);
$correctchoicetext=$correctchoicerow['Textt'];


 if (isset($_SESSION["answersmcq"]))
 {
				
                $countt = count($_SESSION["answersmcq"]);
                $item_arr = array(
				
                   'Qid' => $_GET["id"],
                    'ActualAnswer' => $correctchoicetext,
                    'Answer' => $studentchoicetext,
                     'Lecture' => $grpname,
                     'Status' => "",
                     'Question' => $_POST["questiontext"],
                      'date' =>date("Y-m-d"),
                     'day' =>date("l"),
                       
                      
                );
	
				
                $_SESSION["answersmcq"][$countt] = $item_arr;
  }
  else {
	# code...

$item_arr = array(
				
                   'Qid' => $_GET["id"],
                    'ActualAnswer' => $correctchoicetext,
                    'Answer' => $studentchoicetext,
                     'Lecture' => $grpname,
                     'Status' => "",
                     'Question' => $_POST["questiontext"],
                      'date' =>date("Y-m-d"),
                     'day' =>date("l"),
                       
                      
                );
	
				
                $_SESSION["answersmcq"][0] = $item_arr;
                }
           
 
if($number==$total)
{

$QuestionQueryResult=mysqli_query($conn,"select * FROM questiongroupword where QuesGroupName like '$grpname'");
$rc=mysqli_num_rows($QuestionQueryResult);
if($rc>0)
{
header("Location: Answer_OneWordQuesAssignment.php?groupname=".$grpname);
}
else {
header("Location: MCQfinal.php?LectureTopic=".$lecture_topic);
	# code...
}




}
else{
header("Location: AnswerMCQ2Assignment.php?n=".$next."&lecturetopic=".$lecture_topic."&groupname=".$grpname);

}
}

?>


	