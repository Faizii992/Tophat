

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">


	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link rel="stylesheet" type="text/css" href="css/sourcesanspro-font.css">
	 <title>Student Signup</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">   

      <style>
    body{
     margin:0px;
	}
   @media only screen and (max-width: 600px) {
  .section{
    margin-left:0%;
    margin-top:29%;
  }

  .alert
  {
      margin-top:35%;
  }
  }

   @media only screen and (min-width: 700px) {
  .section{
    margin-left:0%;
    margin-top:15%;
    
  }

  .col-lg-4
  {
      margin-left:24%;
  }
  }


     @media only screen and (min-width: 1025px) {
 
  .section
  { margin-top:5%;
     margin-left:20%;
  }

  .alert
  {
      width:700px;
      margin-left:18%;
  }
  .col-lg-4
  {margin-left:26%;
  
  }

     }

     
     @media only screen and (min-width: 1023px) {
 
  .section
  { margin-top:5%;
     margin-left:20%;
  }

  .alert
  {
      width:700px;
      margin-left:18%;
  }
  .col-lg-4
  {margin-left:32%;
  
  }

     }

    </style>

	</head>
<body>

	
	<?php
	session_start();
include 'tabled.php';
?>
<div class="section">

 <?php
	if(isset($_SESSION['userid']))
    {
     echo '<div style="font-size:20px; text-align:center; padding:1%;margin-top:5%"; class="alert alert-danger">
  <strong>YOU ARE ALREADY LOGGED IN</strong></div> 
  
  ';
	}
    else {
    $msg="";
	if(isset($_GET['error']))
	{$msg=$_GET['error'];
	
	}
	# code...
    if($msg=="invalidemail")
	{  echo' <div style="font-size:20px; text-align:center; padding:1%;margin-top:1%"; class="alert alert-danger">
  <strong>Please enter a valid email</strong></div> '; 
		
	}
	else if($msg=="usertaken")
	{  echo' <div style="font-size:20px; text-align:center; padding:1%;margin-top:2%"; class="alert alert-success">
  <strong>Username is already taken!</strong></div> '; 
		
		
	}
    else if($msg=="passwordcheck")
	{  echo' <div style="font-size:20px; text-align:center; padding:1%;margin-top:2%"; class="alert alert-success">
  <strong>The two passwords dont match!</strong></div> '; 
		
		
	}
	# code...


    ?>

	
                    <div class="container-fluid">
                   
                        <div class="row m-t-25" style="text-align:center;">
                           
                           <div class="col-md-5 col-lg-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">SIGNUP AS A STUDENT</strong>
                                    </div>
                                    <div class="card-body " style="background:#3EB489;">
                                           <img class="rounded-circle mx-auto d-block" style="width:80px;margin-bottom:5%;" src="images/login.png" alt="Card image cap">
                                          <div class="text">
                                               
                                            	 <form action="includes/signupStudent.inc.php" method="post" enctype="multipart/form-data">
                  
                    <input class="form-control" type="text" name="username" placeholder="Enter your Username" class="input-text" required>

                   
                    <input class="form-control" type="text" name="email" placeholder="Enter your Email" class="input-text" required>

                    <input class="form-control" oninvalid="alert('Password Must contain 6 or more characters');" pattern=".{6,}" type="password" name="password" placeholder="Enter Password" class="input-text" required>


                    <input style="margin-bottom:5%;" class="form-control" type="password" name="confirmpassword" placeholder="Confirm Password" class="input-text" required>
                    <button style="margin:auto; display:block;" onclick="http://localhost/Pawesome/loginform.php" type="submit" name="signup" id="signup" class="btn btn-success">Sign Up</button>


                </form>

                                            </div>
                                    </div>
                                </div>
                            </div>
                          
                          
                        </div>
                        <?php
                        }
                        ?>

</body>
</html>