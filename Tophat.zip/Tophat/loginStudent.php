<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">


	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<link rel="stylesheet" type="text/css" href="css/sourcesanspro-font.css">
	 <title>Student Login Page</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/header.css">
     <style>
    body{
     margin:0px;
	}
   @media only screen and (max-width: 693px) {
  .section{
    margin-left:0%;
    margin-top:25%;
  }
  }

   @media only screen and (min-width: 700px) {
  .section{
    margin-left:0%;
    margin-top:15%;
    
  }
  }

   @media only screen and (min-width: 760px) {
 
  .section
  {
     margin-left:35%;
  }

     }
   @media only screen and (min-width: 800px) {
 
  .section
  {
     margin-left:25%;
  }

     }

      @media only screen and (min-width: 990px) {
 
  .section
  { margin-top:5%;
     margin-left:45%;
  }

     }

     @media only screen and (min-width: 1025px) {
 
  .section
  { margin-top:5%;
     margin-left:30%;
  }
  .alert
  {
      width:800px;
  
  }

  .col-lg-4
  {
      margin-left:25%;
  }

     }

    </style>
	</head>
<body>

	<?php
	session_start();
include 'tabled.php';
?>

	<div class="section">

    <?php
    
	if(isset($_SESSION['userid']))
		 				{
						 echo '<div style="font-size:20px; text-align:center; padding:1%; margin-top:2%"; class="alert alert-success">
  <strong>You are already logged in! </strong></div> '; 

	# code...
}
	
 		
	
	else {
	$msg="";
	if(isset($_GET['error']))
	{
	$msg=$_GET['error'];
    
	if($msg=="wrongpwd")
	{  echo' <div style="font-size:20px; text-align:center; padding:1%;margin-top:2%"; class="alert alert-success">
  <strong>TThe Password doesnt match with the account </strong></div> '; 
		
		
	}
	else if($msg=="doesntexist")
	{  echo' <div style="font-size:20px; text-align:center; padding:1%;margin-top:2%"; class="alert alert-success">
  <strong>The Email is not associated with any Student account </strong></div> '; 
		
	
	}
  
	}
    else if(isset($_GET['signup']))
    {
    $msg=$_GET['signup'];
      if($msg=="success")
	{  echo' <div style="font-size:20px; text-align:center; padding:1%;margin-top:2%"; class="alert alert-success">
  <strong>CONGRATULATIONS!</strong>You have successfully created a Student Account!</div> '; 
		
	
	}
	}
  

?>
	
	
	

                    <div class="container-fluid">
                   
                        <div class="row m-t-25" style="text-align:center;">
                           
                            <div class="col-md-5 col-lg-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title" style="color:white;">LOGIN AS A STUDENT</strong>
                                    </div>
                                    <div class="card-body" style="background:#CDE2BB;">
                                            <img class="rounded-circle mx-auto d-block" style="width:80px;margin-bottom:5%;" src="images/login.png" alt="Card image cap">
                                         <div class="text">
                                          
                                                <form action="includes/loginStudent.inc.php" class="form-detail" method="post">						
								
								<input type="email" name="email1"  placeholder="Email" class="form-control" required>							
								<input style="margin-bottom:5%;" type="password" name="password1"  placeholder="Password" class="form-control" required>						
							 <button style="margin:auto;font-size:20px; padding:2.5% 8%; display:block;" onclick="http://localhost/Pawesome/profpageedit.php"  type="submit" id="login2" name="login2"  class="btn btn-success">Sign in</button>			
				</form><a style="color:#808080;margin-top:10%;" href="Signup_sharedview.php"><u>Don't have an account? <br>SIGN UP HERE </u></a>
                                            </div>
                                    </div>
                                </div>
                            </div>
                 
                          
                         

						<?php
						} 
		

						?>
                       
                        </div>
                       
                        </div>

</body>
</html>