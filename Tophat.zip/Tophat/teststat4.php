<!DOCTYPE html>
<html lang="en">

<head>

<?php include 'includes/db.inc.php';
session_start();
unset($_SESSION["answersoneword"]);
?>
	<!-- Required meta tags-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	

	<!-- Title Page-->
	<title>Test Results</title>

	<!-- Fontfaces CSS-->
	<link href="css/font-face.css" rel="stylesheet" media="all">
	<link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
	<link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
	<link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

	<!-- Bootstrap CSS-->
	<link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

	<!-- Vendor CSS-->
	<link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
	<link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
	<link href="vendor/wow/animate.css" rel="stylesheet" media="all">
	<link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
	<link href="vendor/slick/slick.css" rel="stylesheet" media="all">
	<link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
	<link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
      <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">
    <style>
    body{
     margin:0px;
	}
   @media only screen and (max-width: 993px) {
  .w3-container {
    visibility:hidden;
    display:none;
  }
   #tb
  {
      margin-top:15%;
  }

   @media only screen and (max-width: 739px) {
  .w3-container {
    visibility:hidden;
    margin:0px;
    padding:-10px;
    display:none;
  }
  #tb
  {
      margin-top:15%;
  }
   }



    </style>
	<!-- Main CSS-->
	<link href="css/theme.css" rel="stylesheet" media="all">
	<?php //include 'tabled.php'; ?>
	<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>


    $(document).ready(function(){
        $("#scrollmodal").modal('show');
    });
</script>
</head>

<div class="w3-container" style="width:100%;padding-left:0%;padding-right:0%;padding-top:0%;text-align:center;margin:0px;position:fixed;top:0px;z-index:3;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);">

  <div class="w3-bar w3-white" style="padding:2%;margin:0px;text-align:center;">
   
   <a href="index.php" class="w3-bar-item w3-button">Home</a>
   <a href="AssignmentTable.php" class="w3-bar-item w3-button"><i class="fas fa-check-square"></i>Assignments</a>
   <?php
   if(isset($_SESSION['studentLOGIN']))
    {
     echo '<a href="GradeSheet.php" class="w3-bar-item w3-button">Grade Book <i class="fa fa-file-text"></i></a>';
	}
    ?>

      

    <div class="w3-dropdown-hover">
      <button class="w3-button">ABOUT</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">    
              
               
                   <a class="w3-bar-item w3-button" href="developer.php">About The Developer</a>
                   <a class="w3-bar-item w3-button" href="contact.php">Contact</a>
      </div>
    </div>

       <div class="w3-dropdown-hover">
      <button class="w3-button">COURSE</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a class="w3-bar-item w3-button" href="https://www.zybooks.com/" target="_blank">ZyBooks</a>
       <a class="w3-bar-item w3-button" href="https://tophat.com/" target="_blank">TopHat</a>
       <a class="w3-bar-item w3-button" href="https://drive.google.com/drive/folders/1co7vzY9_75cCiuNTHXCGf3pKbpf_TTwC" target="_blank">Course Google Drive</a>
       <a class="w3-bar-item w3-button" href="https://www.w3schools.com/" target="_blank">W3Schools</a>

      </div>
    </div>

    
    <?php

    if(isset($_SESSION['userid']))
    {
    
	?>
        <div class="w3-dropdown-hover">
      <button class="w3-button"><b>MY ACCOUNT </b><i class="fas fa-caret-down"></i></button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4" style="min-width:260px;">
     <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img style="width:50px;"  src="images/login.png" alt="John Doe" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                <?php
                                                echo'
                                                    <h5 class="name">
                                                        <a href="#">'.$_SESSION["username"].'</a>
                                                    </h5> ';
                                                    ?>
                                                    <?php
                                                   echo' <span class="email">'.$_SESSION["email"].'</span> ';
                                                   ?>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account
                                                    </a>
                                                </div>
                                               
                                            </div>
                                            
                                             <div class="account-dropdown__footer">
                                                <a href="includes/logout.inc.php">
                                                    <i class="zmdi zmdi-power"></i>Logout
                                                </a>
                                            </div>
                                        </div>  
                                        
                                      
        

    </div>

     <?php
                                        }
                                        ?>
    
 <?php
 if(isset($_SESSION['professorLogin'])||isset($_SESSION['studentLOGIN']))
 {
  ?>
 <form action="includes/logout.inc.php">
 <button class="w3-bar-item w3-button" style="color:black;" type="submit" name="logout">LOGOUT <i class="fas fa-sign-out-alt" aria-hidden="true"></i></button>
 </form>
 
 <?php
 
 }
 else {
  echo ' <a class="w3-bar-item w3-button" href="Signup_sharedview.php"> SIGNUP </a> 
  <div class="w3-dropdown-hover">
      <button class="w3-button"><i class="fas fa-sign-in-alt"> </i> Sign in</button>
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="loginStudent.php" class="w3-bar-item w3-button">As a Student</a>
        <a href="loginTeacher.php" class="w3-bar-item w3-button">As a Professor</a>
     

      </div>
    </div>
    ';
   // echo ' <a class="w3-bar-item w3-button" href="Signup_sharedview.php"><i class="fas fa-sign-in-alt"> </i> SIGN IN </a> ';
	# code...
}

 ?>
  <a class="w3-bar-item w3-button" href="developer.php">Help</a>


  </div>
</div>
<body class="animsition" style="animation-duration: 0ms; opacity: 1;">

						<table id="tabled" style="margin-top:1%;margin-bottom:1%; padding-bottom:2%; width:100%;" class="table table-striped table-bordered">
 <thead class="thead-dark">
            <tr>
			<th width="12%">Student ID</th>
                <th width="12%">Student Username</th>
                <th width="8%">Student Email</th>
               
                <th width="8%">Marks</th>
                  
                <th width="10%">Detailed Marks</th>
				<th width="10%">Date Taken</th>
            </tr>
		</thead>	
		    <?php
                                              
											  $lec="";
											  if(isset($_GET["lec"]))
											  { $lec=$_GET["lec"];
											  }
											   $type="";
											  if(isset($_GET["type"]))
											  { $type=$_GET["type"];
											  }

											  if($type=="wa")
											  {
											  echo '<h4 style="color:green;">'.'ASSIGNMENT: </h4><p>'.$lec.'</p>';
											   echo '<h4 style="color:black;margin-top:2%;">'.'WORD ANSWER RESULTS </h4>';
$QuestionQueryResult=mysqli_query($conn,"select * FROM warevstat where lecturetopic LIKE '$lec'");
while($QuestionRow=mysqli_fetch_array($QuestionQueryResult))
{
  
                    echo '<tr>';
					$id=$QuestionRow["sid"];
  $fetch=mysqli_query($conn,"select sID,Email,Username FROM studentregistration where sID =$id");
  $fetchrow=mysqli_fetch_assoc($fetch);
   echo  ' <td>'.$fetchrow["sID"]. '</td> ';
  echo  ' <td>'.$fetchrow["Username"]. '</td> ';
   echo  ' <td>'.$fetchrow["Email"]. '</td> 
                          <td> <b>'.$QuestionRow["totalpoints"].'/'.$QuestionRow["totalquesno"].'</b></td> ';
							
                        
                        
                        ?>  
							
							 <td>
                                                
                                                <a href="teststat2.php?lecc=<?php echo $lec; ?>&id=<?php echo $QuestionRow["sid"]; ?>" style="color:white;" class="btn btn-secondary mb-1">
											<i class="mr-2 fa fa-align-justify"></i>Show Content
										</a></td>
										<td><?php echo $QuestionRow["datetaken"]; ?></td>
							
                          

<?php
  
                    


                     echo '</tr>';
                                             
       
           }
             echo '   </table> '; 
			
                 
											  }
											  else if($type=="mcq")
											  {
											  echo '<h4 style="color:green;">'.'ASSIGNMENT: </h4><p>'.$lec.'</p>';
											   echo '<h4 style="color:black;margin-top:2%;">'.'WORD ANSWER RESULTS </h4>';
$QuestionQueryResult=mysqli_query($conn,"select * FROM mcqrevstat where lecturetopic LIKE '$lec'");
while($QuestionRow=mysqli_fetch_array($QuestionQueryResult))
{
  
                    echo '<tr>';
					$id=$QuestionRow["sid"];
  $fetch=mysqli_query($conn,"select sID,Email,Username FROM studentregistration where sID =$id");
  $fetchrow=mysqli_fetch_assoc($fetch);
   echo  ' <td>'.$fetchrow["sID"]. '</td> ';
  echo  ' <td>'.$fetchrow["Username"]. '</td> ';
   echo  ' <td>'.$fetchrow["Email"]. '</td> 
                          <td> <b>'.$QuestionRow["totalpoints"].'/'.$QuestionRow["totalquesno"].'</b></td> ';
							
                        
                        
                        ?>  
							
							 <td>
                                                
                                                <a href="teststat.php?lecc=<?php echo $lec; ?>&id=<?php echo $QuestionRow["sid"]; ?>" style="color:white;" class="btn btn-secondary mb-1">
											<i class="mr-2 fa fa-align-justify"></i>Show Content
										</a></td>
										<td><?php echo $QuestionRow["datetaken"]; ?></td>
							
                          

<?php
  
                    


                     echo '</tr>';
                                             
       
           }
             echo '   </table> '; 
			
                
											  }
											  else if($type=="mcqwa")
											  {
											   echo '<h4 style="color:green;">'.'ASSIGNMENT: </h4><p>'.$lec.'</p>';
											   echo '<h4 style="color:black;margin-top:2%;">'.'WORD ANSWER RESULTS </h4>';
$QuestionQueryResult=mysqli_query($conn,"select * FROM amcqrevstat where lecturetopic LIKE '$lec'");
while($QuestionRow=mysqli_fetch_array($QuestionQueryResult))
{
  
                    echo '<tr>';
					$id=$QuestionRow["sid"];
  $fetch=mysqli_query($conn,"select sID,Email,Username FROM studentregistration where sID =$id");
  $fetchrow=mysqli_fetch_assoc($fetch);

    $fetchwa=mysqli_query($conn,"select * from awarevstat where sid =$id and lecturetopic LIKE '$lec'");
  $fetchwarow=mysqli_fetch_assoc($fetchwa);
  $totalques=$QuestionRow["totalquesno"]+$fetchwarow["totalquesno"];
   $totalpoints=$QuestionRow["totalpoints"]+$fetchwarow["totalpoints"];
    echo  ' <td>'.$fetchrow["sID"]. '</td> ';
  echo  ' <td>'.$fetchrow["Username"]. '</td> ';
   echo  ' <td>'.$fetchrow["Email"]. '</td> 


                          <td> <b>'.$totalpoints.'/'.$totalques.'</b></td> ';
							
                        
                        
                        ?>  
							
							 <td>
                                                
                                                <a href="teststat3.php?lecc=<?php echo $lec; ?>&id=<?php echo $QuestionRow["sid"]; ?>" style="color:white;" class="btn btn-secondary mb-1">
											<i class="mr-2 fa fa-align-justify"></i>Show Content
										</a></td>
										<td><?php echo $QuestionRow["datetaken"]; ?></td>
							
                          

<?php
  
                    


                     echo '</tr>';
                                             
       
           }
             echo '   </table> '; 
			
                 
											  }

											  ?>
											 
                                            
                                              
				 				
</body>

	<!-- Jquery JS-->
	<script src="vendor/jquery-3.2.1.min.js"></script>
	<!-- Bootstrap JS-->
	<script src="vendor/bootstrap-4.1/popper.min.js"></script>
	<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
	<!-- Vendor JS       -->
	<script src="vendor/slick/slick.min.js">
	</script>
	<script src="vendor/wow/wow.min.js"></script>
	<script src="vendor/animsition/animsition.min.js"></script>
	<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
	</script>
	<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
	<script src="vendor/counter-up/jquery.counterup.min.js">
	</script>
	<script src="vendor/circle-progress/circle-progress.min.js"></script>
	<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
	<script src="vendor/chartjs/Chart.bundle.min.js"></script>
	<script src="vendor/select2/select2.min.js">
	</script>

	<!-- Main JS-->
	<script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
