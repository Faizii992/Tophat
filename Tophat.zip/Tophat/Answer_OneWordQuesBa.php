
<?php
    session_start();
	require 'includes/db.inc.php';
    $lecture_topic="";
    if(isset($_GET['lecturetopic']))
    {
    $lecture_topic=(string)$_GET['lecturetopic'];
	}
      

 

?>

<style>

 body
     { text-align:center;}

    
    
input[type="text"]
{
    font-size:18px;
    width:400px;
    margin:auto;
    text-align:center;
   
   
   
}

</style>




<!doctype html>

<html>

<head>
<title>
Word Answer Questions
</title>


<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="css/bootstrap.min.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <style>
   @media only screen and (max-width: 590px) {
  .content
  {
  margin-top:30%;
  margin-left:0%;
 
  }
  }

   @media only screen and (max-width: 490px) {
  .content
  {
  margin-top:40%;
  margin-left:0%;
 
  }

  .alert-class
  {
      margin-top:15%;
  }

  }

   @media only screen and (max-width: 990px) {
  .content
  {
  margin-top:20%;
  margin-left:0%;
 
  }
  }

   @media only screen and (max-width: 790px) {
  .content
  {
  margin-top:30%;
  margin-left:0%;
 
  }
   .alert-class
  {
      margin-top:15%;
  }

  }

   @media only screen and (min-width: 1025px) {
  .content
  {
  margin-top:5%;
  margin-left:18%;
 
  }

  .alert
  {
      width:700px;
  }

  .alert-class{
  margin-top:5%;
      margin-left:35%;
  }

  

  }

  @media only screen and (min-width: 1023px) {
  .content
  {
  margin-top:5%;
  margin-left:18%;
 
  }

  .alert
  {
      width:700px;

  }
  #notopic
  {
      margin-left:18%;
  }

  .alert-class{
  margin-top:5%;
      margin-left:30%;
  }

  }

</style>
</head>

<body>
 <?php 
    include 'tabled.php';
?>
<?php

if(isset($_SESSION['studentLOGIN']))
{

    if (isset($_POST["submitAnswers"])){
   
        if (isset($_SESSION["answersoneword"])){

           
            $item_array_id = array_column($_SESSION["answersoneword"],"Qid");
            if (!in_array($_GET["id"],$item_array_id)){
				
                $count = count($_SESSION["answersoneword"]);
                $item_array = array(
				
                   'Qid' => $_GET["id"],
                    'ActualAnswer' => $_POST["actualans"],
                    'Answer' => $_POST["answer"],
                     'Lecture' => $_POST["lecturetopic"],
                     'Status' => "",
                     'Question' => $_POST["question"],
                       'answeredcorrectly' => 0,
                       'date' =>date("Y-m-d"),
                     'day' =>date("l"),
                      
                );
	
				
                $_SESSION["answersoneword"][$count] = $item_array;
               
                
                
                
                }
                else{
                
			echo'	 <div class="alert alert-danger" style="padding:1%; margin-left:40%;width:400px; text-align:center;">
  <strong>You have already answered this! </strong>  
</div> ';
       echo '<script>alert("Warning!You have already answered this question!")</script>';

          
               //  echo '<script>window.location="shoppingcartdetails.php"</script>';
																					
				}
                }
                else {
              $item_array = array(
            'Qid' => $_GET["id"],
                    'ActualAnswer' => $_POST["actualans"],
                    'Answer' => $_POST["answer"],
                     'Lecture' => $_POST["lecturetopic"],
                     'Status' => "",
                       'Question' => $_POST["question"],
                       'answeredcorrectly' => 0,
                       'date' =>date("Y-m-d"),
                     'day' =>date("l"),
              
            );
            $_SESSION["answersoneword"][0] = $item_array; 
	# code...
}
 
		              
			
 		
            }  
        
    

?>
<?php

$SID=$_SESSION['userid'];
$QuestionQResult=mysqli_query($conn,"select * FROM warevstat where sid=$SID and LectureTopic Like '$lecture_topic'");

$check=mysqli_num_rows($QuestionQResult);
if($check>0)
{echo '<div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%"; class="alert alert-danger">
  <strong>You have already taken this quiz!</strong></div> 
  <div style="font-size:20px; text-align:center; padding:1%"; class="alert alert-success">
  <strong><a id="takelec" href="GradeSheet.php" > YOU CAN FIND ALL YOUR TEST RESULTS IN YOUR GRADEBOOK</a></strong></div>
  
  </div>
  ';
  

}
else {
	# code...


?>
<div class="content" style="text-align:center">

<p style="text-align:center; text-transform:Uppercase;"> <b> *Answer the questions in just one word</b></p> 
<p style="text-align:center;">*PLEASE <b>CLICK SUBMIT </b>BUTTON AFTER WRITING EVERY ANSWER OTHERWISE YOUR MARK WONT BE COUNTED</p> 
<p style="text-align:center;">*Click the <b>Calculate Grade</b> button once you're done</p> 

<a href="instructionsMCQ.php" style="text-align:center;color:blue;margin-bottom:1.5%;"><u> See more of these instructions on how to answer the questions properly </u></a>

<?php
 

$QuestionQueryResult=mysqli_query($conn,"select * FROM one_word_questions where LectureTopic like '$lecture_topic'");
$AnsQueryResult=mysqli_query($conn,"select * FROM answertablemcq where LectureTopic like ' $lecture_topic'");
$Row_Count=mysqli_num_rows($QuestionQueryResult);
if($Row_Count!=0)
{


while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	{	

?>


  <h3 style="color:green; text-align:center; text-transform:Capitalize; margin:2.5% 0% 0.5% 0%;"><?php echo $Questionrow["Question"] ?>?</h3>

<form method="post"  action="Answer_OneWordQuesBa.php?&lecturetopic=<?php echo $lecture_topic; ?>&id=<?php echo $Questionrow["Qid"]; ?>">
 

        <input type="text" class="form-control"  placeholder="Enter Answer Here" name="answer">
        <input type="hidden"  name="actualans" value="<?php echo $Questionrow["ActualAnswer"]; ?> ">
         <input type="hidden"  name="question" value="<?php echo $Questionrow["Question"]; ?> ">
         
         <input type="hidden"  name="lecturetopic" value="<?php echo $Questionrow["LectureTopic"]; ?>" >
        
      <button type="submit" id="submitAnswers" name="submitAnswers"
     style="font-size:15px; padding:0.4% 2%; margin:auto; display:block; margin-top:1%;"  class="btn btn-success">Submit</button>

<br>

    
   
  </form>
  <?php
  }
 
  ?>
    <a name="Finish"
     style="font-size:15px;margin-bottom:5%;" href="GradeOneWord.php" class="btn btn-success">Calculate Grade</a>

 <hr>
 <?php
 }
 
 else {
  echo '
 <script>
 window.alert("There is no one word question answer related to this topic!");
 </script>

<div id="notopic" style="font-size:20px; text-align:center; padding:1%; margin-top:5%"; class="alert alert-danger">
  <strong>There is no one word question answer related to this topic!</strong></div> ';
	
}
}

}


else {
	 echo '
     <div class="alert-class">
     <div style="font-size:20px; text-align:center; padding:1%;" class="alert alert-danger">
  <strong>You need to be have a Student Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%;" class="alert alert-success">
  <strong>Sign up and Login using a Student account </strong><a href="Signup_sharedview.php">HERE</a></div> 
  </div>
  ';
}

?>
     </div> 
</body>

</html>
