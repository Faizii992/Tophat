<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>
MCQ Results
</title>
     <link rel="stylesheet" href="css/header.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
   
 
    @media only screen and (min-width: 767px) {
   .content
   {
       margin-left:25%;
   }

   .alert
   {
       width:600px;
       margin-left:34%;
   }
  
   #tabled
   {
       margin-left:16%;
   }
 

  }


     @media only screen and (max-width: 600px) {
 #takelec
 {
     margin-left:30%;
 }
   #tabled
   {
       margin-left:12%;
   }
 .container_txt
 {
     margin-top:28%;
 }

  }

  @media only screen and (min-width: 768px) {
 #takelec
 {
     margin-left:30%;
 }
   #tabled
   {
       margin-left:22%;
   }
 .container_txt
 {
     margin-top:18%;
 }

  }
     @media only screen and (min-width: 1025px) {
 #takelec
 {
     margin-left:30%;
 }
   #tabled
   {
       margin-left:25%;
   }
 .container_txt
 { margin-left:15%;
     margin-top:3%;
 }

  }

   @media only screen and (min-width: 1023px) {
 #takelec
 {
     margin-left:30%;
 }
   #tabled
   {
       margin-left:38%;
   }
 .container_txt
 { margin-left:15%;
     margin-top:3%;
 }

  }
 
    
  </style>
</head>
<?php
session_start();


?>
<?php 
    include 'tabled.php';
    $lecturetopic="";
    if(isset($_GET['LectureTopic']))
    {
      $lecturetopic=$_GET['LectureTopic'];
	}
  

?>
<body>
<?php 

  if(!isset($_SESSION['answersmcq']))
  {
       echo '
       <div style="font-size:20px; text-align:center; padding:1%; margin-top:2%";margin-bottom:5%; class="alert alert-success">
  <a href="GradeSheet.php"> YOU CAN FIND ALL YOUR TEST RESULTS IN YOUR GRADEBOOK</a></div>
       
       <div style="font-size:20px; text-align:center; padding:1%; margin-top:2%";margin-bottom:5%; class="alert alert-success">
  <strong>There is nothing to show!</strong></div> 
  
  '; 
    echo ' 
   <a id="takelec" href="ChoosingLectureType.php?type=mcq" style="margin-bottom:5%;padding:1% 2%;font-size:18px;margin-top:1%;" class="btn btn-success"> COMPLETE MORE MCQ BASED ASSIGNMENTS! </a>
  '; 
  
  }
  else {
	# code...


?>

  <div class="container_txt" style="margin-bottom:3%;text-align:center;">
   
    <h2 style="color:green;">YOUR'E DONE!</h2>
    <h3> Congrats! You have completed the test. </h3>
    <p> Final Score : <?php echo $_SESSION['mcq_score']; ?> 
  <h1>RESULTS</h1>
    
</div>


<table id="tabled" style="margin-top:3%;margin-bottom:1%; padding-bottom:2%; width:52.5%;" class="table table-striped table-bordered">
 <thead class="thead-dark">
            <tr>
                <th width="12%">QUESTION </th>
                <th width="8%">Actual Answer</th>
               
                <th width="8%">Student's Answer</th>
                  
                <th width="10%">Status</th>
            </tr>
		</thead>	
			<?php
			 
   $correctcnt=0;		
    $wrongcnt=0;
    $cnt=0;
					
                    foreach ($_SESSION["answersmcq"] as $key => $value) {
                    $cnt++;
                       $_SESSION["status"]="";	
    $value["Status"]="Wrong";
    if(strcasecmp($value["ActualAnswer"],$value["Answer"])==0)
    {
  
     $value["Status"]="Correct";
  
    //break;
	}
    else {
     $value["Status"]="Wrong";
}

   
   
                    echo '<tr>
                          <td> <b>'.$value["Question"].'?</b></td> ';
							
                         echo  ' <td>'.$value["ActualAnswer"]. '</td> ';
                        
                            echo '<td>'.$value["Answer"].'</td>';  
                             
                          
                          
 if($value["Status"]=="Correct")
 {
       echo '<td style="background-color:#50C878;"><b></b>'. $value["Status"] . '</td>';
 }
 else {
	echo ' <td style="background-color:#CA3444; color:white;"><b></b>'. $value["Status"] . '</td> ';
}
$stat=$value["Status"];
$ans=$value["Answer"];
$actans=$value["ActualAnswer"];
$ques=$value["Question"];
$userid=$_SESSION["userid"];
$qid=$value["Qid"];
$day=$value["day"];
$date=$value["date"];
$lecture=$value["Lecture"];

        $resultx=mysqli_query($conn,"INSERT into mcqresultrev(sid,actualAnswer,studentsanswer,status,question,mcqquesid,lecturetopic) VALUES
('$userid','$actans','$ans','$stat','$ques','$qid','$lecture')");             


                     echo '</tr>';
                                             
       
           }
             echo '   </table> '; 
             $score=$_SESSION["mcq_score"];
             
                  $resulty=mysqli_query($conn,"INSERT into mcqrevstat(sid,daytaken,datetaken,totalpoints,mcqquesid,totalquesno,lecturetopic) VALUES
('$userid','$day','$date','$score','$qid','$cnt','$lecture')"); 
            ?>

       <div class="container col-md-9" style="margin-left:10%;text-align:center;">
       
  <a href="ChoosingLectureType.php?type=mcq" style="margin-bottom:5%;padding:1% 2%;font-size:18px;margin-top:1%;" class="btn btn-success"> Find more mcq based assignments! </a>


 
</div>
<?php
}
?>
</body>
<?php
unset($_SESSION['mcq_score']);
unset($_SESSION['answersmcq']);
?>

</html>