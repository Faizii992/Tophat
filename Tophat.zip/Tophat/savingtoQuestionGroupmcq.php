﻿
<?php
	require 'includes/db.inc.php';


    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Saving to Question Group</title>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/header.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
     h1{
         
        color: #f9f9f9;
        text-align: center;
     }
     p{
        color: black;
        opacity:0.5;
     }
     h4
     {
      color:green;
      text-transform:capitalize;
     
      
	 }
    input[type="text"]
     {
      max-width:450px;
      min-width:400px;
     
	 }
     body
     { text-align:center;}

    .form-horizontal

    { display:inline-block;}

    .form-control{
     margin:1% 0% ;
	}

    @media only screen and (min-width: 992px) {
  .section{
    margin-left:32%;
    margin-top:5%;
    
  }
  }
    @media only screen and (max-width: 692px) {
  .section{
    margin-left:2%;
    margin-top:25%;
    
  }
  input[type="text"]
     {
      max-width:400px;
      min-width:300px;
     
	 }

  }
   
    
  </style>
</head>
<?php include 'tabled.php'; ?>

<body>
<?php

if(isset($_SESSION['professorLogin']))
{

?>

   <div class="section">
  <div>

  <div class="container">

  <form class="form-horizontal" action="includes/savingtoQuestionGroup.incmcq.php" method="post">
    

    <h3 style="margin-top:3%;">Enter the Group name:</h3>
        <input type="text" class="form-control"  placeholder="Enter the Question Group Name" name="questiongroup">
      


  <h3 style="margin-top:5%"> Add mcq questions to the group: </h3>
  <p>Hold down the Ctrl (windows) or Command (Mac) button to select multiple options.</p>
    <form action="includes/savingtoQuestionGroup.inc.php" method="post">

  <select style="width:450px;" name="ary2[]" multiple="multiple">
      <?php
    {
     
$QuestionQueryResult=mysqli_query($conn,"select  * FROM assignment_mcq_questions");
while($Questionrow=mysqli_fetch_array($QuestionQueryResult))
	{

    ?>
    <option value="<?php echo $Questionrow["QuestionID"]; ?> "><?php echo $Questionrow["Textt"]; ?> </option>


    <?php
    }
    }

    ?>
  </select>

                              
  <button type="submit" id="submitmcq" name="submitmcq"
     style="font-size:20px; padding:1% 3%; margin:5% 5% 5% 0%; display:block;"  class="btn btn-success">Submit Group Name</button>
</form>
</div>
</div>
<?php
}

else {
	 echo '<div style="font-size:20px; text-align:center; padding:1%; width:500px;margin-left:35%;margin-top:5%"; class="alert alert-danger">
  <strong>You need to be have a Professor Account to avail this feature</strong></div> 
  
  '; 
   echo '<div style="font-size:20px; text-align:center; padding:1%; width:500px;margin-left:35%;margin-top:3%"; class="alert alert-success">
  <strong>Sign up using a Professor or Student account</strong><a href="Signup_sharedview.php">HERE</a></div> 
  
  ';
}

?>

</div>
</body>
</html>