

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">

    <title>
CS355 Choose Assignment Type
</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link rel="stylesheet" type="text/css" href="css/sourcesanspro-font.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
 <style>
    body{
     margin:0px;
	}
   @media only screen and (max-width: 693px) {
  .section{
    margin-left:0%;
    margin-top:25%;
  }
  }

   @media only screen and (min-width: 700px) {
  .section{
    margin-left:0%;
    margin-top:15%;
    
  }
  }

   @media only screen and (min-width: 800px) {
 
  .section
  {
     margin-left:25%;
  }

     }

       @media only screen and (min-width: 1000px) {
 
  .section
  { margin-top:5%;
     margin-left:35%;
  }

  .col-lg-5
  {
      margin-right:4%;
  }

     }

     @media only screen and (min-width: 1025px) {
 
  .section
  { margin-top:5%;
     margin-left:25%;
  }

  .col-lg-5
  {
      margin-right:4%;
  }
  .alert
  {
      width:800px;
      margin-left:5%;
  }

     }

      @media only screen and (min-width: 1023px) {
 
  .section
  { margin-top:5%;
     margin-left:25%;
  }

  .col-lg-5
  {
      margin-right:4%;
  }
  .alert
  {
      width:600px;
      margin-left:12%;
  }

     }

    </style>
</head>

    <?php
    session_start();
    include 'tabled.php';

    ?>

      <div class="section">
    <?php
    if(!isset($_SESSION['professorLogin']))
    {
     echo '<div style="font-size:20px; text-align:center; padding:1%;margin-top:5%"; class="alert alert-danger">
  <strong>You need to login to avail this feature </strong></div> 
  
  ';
	}
    else {
	# code...


    ?>
  
                    <div class="container-fluid">
                   
                        <div class="row m-t-25" style="text-align:center;">
                           <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">Add<br>MCQ + Word Answer Based Questions</strong>
                                    </div>
                                    <div class="card-body " style="background:#3EB489;">
                                  
                                            <div class="text">
                                              
                                                
                                                 <p style="color:white;">Create questions consisting of both word answers and multiple choice questions</p>
                                                   
                                                 
                                                     <a href="addMCQAssignment.php?type=both" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:white;color:black; margin-top:6%;margin-bottom:5%;">Start adding Questions!</a>


                                            </div>
                                        <p class="card-text text-light">Click the button below to see the rules for adding MCQ + Word Answer Based Questions </p>
                                          <div class="text">
                                               
                                                   
                                                  <a href="instructions1.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="color:white;background-color:black; margin-top:5%;">View Instructions</a>
                                                   


                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title" style="color:white;">Add <br>MCQ <br>Based Questions only</strong>
                                    </div>
                                    <div class="card-body" style="background:#CDE2BB;">
                                        <div class="text">
                                                
                                                <span>Create Multiple Choice Questions to test your student's knowledge</span>
                                             
                                                   
                                                 
                                                     <a href="addMCQ.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:white;color:black; margin-top:6%;margin-bottom:6%;">Start adding MCQ!</a>


                                            </div>
                                                    <p class="card-text ">Click the button below to see the rules for adding Multiple Choice Questions
                                        </p>
                                                     <a href="instructions2.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:black;color:white;margin-top:4%;">View Instructions</a>
                                            </div>
                                    </div>

                              


                            </div>
                               <div class="col-md-4">
                                <div class="card" style="text-align:center;">
                                    <div class="card-header bg-dark">
                                        <strong class="card-title text-light">Add <br>Word Answer<br> Based Questions Only</strong>
                                    </div>
                                    <div class="card-body " style="background:#3EB489;">
                                       
                                          <div class="text">
                                            
                                               
                                                <span style="color:white;">Answer in one word questions to test your student's knowledge</span>
                                                 
                                                   
                                                 
                                                     <a href="add_OneWordQues.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="background-color:white;color:black; margin-top:6%;margin-bottom:5%;">Start adding Word Answers!</a>

                                                     <br>
                                            </div>
                                                    <p class="card-text text-light">Click the button below to see the rules for adding Word Answer Based Questions </p>
                                                  <a href="instructions3.php" class="btn btn-default"name="lecturetopic" value="<?php echo $lecture_topic; ?>" style="color:white;background-color:black; margin-top:5%;">View Instructions</a>
                                                   


                                            </div>
                                    </div>
                                </div>
                             
                               
                        <?php
                        }
                        ?>

                        
</div>
</div>



</body>
</html>